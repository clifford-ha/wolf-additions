#include "/lib/colors/skyColors.glsl"

#ifdef SHOOTING_STARS

float ShootingStarHash(vec2 x) {
    return fract(sin(dot(x, vec2(11.0, 57.0))) * 4000.0);
}

float ShootingStarCell(vec2 x, float time) {
    x *= mat2(cos(0.5), -sin(0.5), sin(0.5), cos(0.5));
    x.y += time;

    float shape = 1.0 - length(fract(x - vec2(0.0, 0.5)) - 0.5);
    x *= vec2(1.0, 0.085);
    vec2 fr = fract(x);

    float random = step(ShootingStarHash(floor(x)), 0.003);
    float tall = (1.0 - (abs(fr.x - 0.5) + fr.y)) * random;

    return clamp(
        clamp((shape - random) * step(ShootingStarHash(floor(x + vec2(0.0, 0.05))), 0.003), 0.0, 1.0) + tall,
        0.0, 1.0
    );
}

vec3 GetShootingStars(vec2 starCoord, float VdotU, float VdotS) {
    if (VdotU < 0.0) return vec3(0.0);

    float speedMult = SHOOTING_STAR_SPEED * 0.01;
    float bloomMult = max(SHOOTING_STAR_BLOOM * 0.01, 0.12);
    float intensityMult = SHOOTING_STAR_I * 0.01;

    vec3 starColor = vec3(SHOOTING_STAR_R, SHOOTING_STAR_G, SHOOTING_STAR_B) / vec3(100.0, 100.0, 100.0);
    starColor = mix(vec3(dot(starColor, vec3(0.299, 0.587, 0.114))), starColor, 1.5);

    float safeTime = mod(frameTimeCounter, 3600.0);
    float time = safeTime * 16.0 * speedMult;

    float starVal = ShootingStarCell(starCoord * 64.0, time);
    if (starVal <= 0.0) return vec3(0.0);

    vec3 bloomExp = vec3(20.0) * bloomMult;
    vec3 col = pow(vec3(starVal), bloomExp) * starColor;

    float halo = pow(starVal, 6.0 / bloomMult);
    col += halo * starColor * 0.012 * bloomMult;

    float visibility = min1(VdotU * 3.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));
    visibility *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.5 * sunVisibility);

    return col * 60.0 * intensityMult * visibility;
}
#endif

float GetStarNoise(vec2 pos) {
    return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.54953);
}

vec2 GetStarCoord(vec3 viewPos, float sphereness) {
    vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos * 1000.0, 1.0)).xyz);
    vec3 starCoord = wpos / (wpos.y + length(wpos.xz) * sphereness);
    starCoord.x += 0.006 * syncedTime;
    return starCoord.xz;
}

vec3 GetStars(vec2 starCoord, float VdotU, float VdotS) {
    #if NIGHT_STAR_AMOUNT == 0
        return vec3(0.0, 0.0, 0.0);
    #endif
    if (VdotU < 0.0) return vec3(0.0);

    starCoord *= 0.2;
    float starFactor = 1024.0;
    starCoord = floor(starCoord * starFactor) / starFactor;

    float star = 1.0;
    star *= GetStarNoise(starCoord.xy);
    star *= GetStarNoise(starCoord.xy+0.1);
    star *= GetStarNoise(starCoord.xy+0.23);

    #if NIGHT_STAR_AMOUNT == 1
        star -= 0.82;
        star *= 2.0;
    #elif NIGHT_STAR_AMOUNT == 2
        star -= 0.7;
    #elif NIGHT_STAR_AMOUNT == 3
        star -= 0.62;
        star *= 0.75;
    #elif NIGHT_STAR_AMOUNT == 4
        star -= 0.52;
        star *= 0.55;
    #endif
    star = max0(star);
    star *= star;

    star *= min1(VdotU * 3.0) * max0(1.0 - pow(abs(VdotS) * 1.002, 100.0));
    star *= invRainFactor * pow2(pow2(invNoonFactor2)) * (1.0 - 0.5 * sunVisibility);

    return 40.0 * star * vec3(0.38, 0.4, 0.5);
}