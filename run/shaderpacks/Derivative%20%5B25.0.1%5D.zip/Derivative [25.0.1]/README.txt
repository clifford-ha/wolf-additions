


=============================================================================================================

All Rights Reserved

Copyright (C) 2025 Mizore
Derivative Main 25 Build 



If you use the source code and publish a DERCODE/Der fork publicly, please include [ DC FORK ] in the README or in the shader’s name, or leave a link to the original DERCODE.


Thank you for your attention.

=============================================================================================================






