/*
================================================================================
  GI_SSIL_Bitmask.glsl  —  Screen Space Indirect Lighting with Visibility Bitmask
  ==================================================================================

  Расширенная реализация SSIL по статье:
  "Screen Space Indirect Lighting with Visibility Bitmask"
  Olivier Therrien, Yannick Levesque, Guillaume Gilet (arXiv 2301.11376)

  Улучшения над базовой реализацией:
    • 2-уровневый LOD horizon search (ближний + дальний)
    • Specular occlusion через bent normal
    • Variable step size (экспоненциальный рост шагов)
    • Decoupled sky irradiance через SH2 с bent normal
    • Half-resolution опция (SSIL_HALF_RES)
    • Temporal bitmask accumulation через history buffer

  Настройки:
    SSIL_SLICES        6     // угловых срезов
    SSIL_STEPS         6     // шагов на срез (горизонтов)
    SSIL_RADIUS        2.0   // радиус поиска (метры)
    SSIL_STRENGTH      1.0   // яркость GI
    SSIL_AO_STRENGTH   1.0   // яркость AO
    SSIL_HALF_RES      0     // полуразрешение (0=full, 1=half)
    SSIL_BENT_SPECULAR 1     // specular occlusion через bent normal
    SSIL_EXP_STEPS     1     // экспоненциальный рост шагов
================================================================================
*/

#include "/lib/GI/GI_Common.inc"

#ifndef SSIL_SLICES
    #define SSIL_SLICES 6
#endif
#ifndef SSIL_STEPS
    #define SSIL_STEPS 6
#endif
#ifndef SSIL_RADIUS
    #define SSIL_RADIUS 2.0
#endif
#ifndef SSIL_STRENGTH
    #define SSIL_STRENGTH 1.0
#endif
#ifndef SSIL_AO_STRENGTH
    #define SSIL_AO_STRENGTH 1.0
#endif
#ifndef SSIL_HALF_RES
    #define SSIL_HALF_RES 0
#endif
#ifndef SSIL_BENT_SPECULAR
    #define SSIL_BENT_SPECULAR 1
#endif
#ifndef SSIL_EXP_STEPS
    #define SSIL_EXP_STEPS 0
#endif

// ─────────────────────────────────────────────────────────────────────────────
// Bitmask helpers
// ─────────────────────────────────────────────────────────────────────────────

// Конвертировать sinTheta ∈ [-1, 1] → sector ∈ [0..31]
uint SSIL_ElevToSector(float sinTheta) {
    return uint(clamp((sinTheta * 0.5 + 0.5) * 32.0, 0.0, 31.0));
}

// Заполнить все биты в диапазоне [sMin..sMax]
uint SSIL_FillRange(uint sMin, uint sMax) {
    if (sMin > sMax) return 0u;
    uint count = sMax - sMin + 1u;
    return ((count >= 32u) ? 0xFFFFFFFFu : ((1u << count) - 1u)) << sMin;
}

// Видимость по битмаску (доля незаблокированных)
float SSIL_BitmaskVis(uint mask) {
    return float(bitCount(mask)) * (1.0 / 32.0);
}

// ─────────────────────────────────────────────────────────────────────────────
// G-buffer хелперы
// ─────────────────────────────────────────────────────────────────────────────

vec3  SSIL_GetVP(vec2 uv)    { return ScreenToViewSpaceRaw(vec3(uv, textureLod(depthtex0, uv, 0.0).x)); }
vec3  SSIL_GetN(vec2 uv)     { return DecodeNormal(textureLod(colortex3, uv, 0.0).xy); }
vec3  SSIL_GetColor(vec2 uv) { return max(vec3(0.0), textureLod(colortex6, uv, 0.0).rgb); }

// ─────────────────────────────────────────────────────────────────────────────
// Шаг по срезу с экспоненциальным или линейным шагом
// ─────────────────────────────────────────────────────────────────────────────

float SSIL_StepSize(int s, float baseStep) {
    #if SSIL_EXP_STEPS == 1
        // Экспоненциальный рост: близкие шаги плотнее
        return baseStep * pow(1.6, float(s));
    #else
        return baseStep * float(s);
    #endif
}

// ─────────────────────────────────────────────────────────────────────────────
// Один срез SSIL
//
//    Для заданного направления sliceDirSS идёт в +dir и -dir,
//    обновляет bitmask, накапливает irradiance и AO.
// ─────────────────────────────────────────────────────────────────────────────

struct SSIL_SliceResult {
    vec3  irradiance;
    uint  occlusionMask;  // биты = заблокированные сектора
};

SSIL_SliceResult SSIL_Slice(
    vec2 uv,
    vec3 viewPos,
    vec3 viewNormal,
    vec2 sliceDirSS,     // экранное направление (aspect-corrected)
    float baseStep       // базовый шаг (в UV)
) {
    SSIL_SliceResult result;
    result.irradiance    = vec3(0.0);
    result.occlusionMask = 0u;

    uint maskPos = 0u;
    uint maskNeg = 0u;

    float sinHPos = -1.0;
    float sinHNeg = -1.0;

    for (int s = 1; s <= SSIL_STEPS; ++s) {
        float dist = SSIL_StepSize(s, baseStep);

        // ── Положительное направление ──
        {
            vec2  sUV  = uv + sliceDirSS * dist;
            if (clamp(sUV, vec2(0.001), vec2(0.999)) == sUV) {
                float sDepth = textureLod(depthtex0, sUV, 0.0).x;
                if (sDepth < 1.0) {
                    vec3  sVP   = SSIL_GetVP(sUV);
                    vec3  hVec  = sVP - viewPos;
                    float hLen  = length(hVec);

                    if (hLen > 1e-3 && hLen < SSIL_RADIUS) {
                        vec3  hDir = hVec / hLen;
                        float sinH = hDir.z;

                        if (sinH > sinHPos) {
                            // Обновляем bitmask
                            uint s0 = SSIL_ElevToSector(sinHPos);
                            uint s1 = SSIL_ElevToSector(sinH);
                            maskPos |= SSIL_FillRange(s0, s1);
                            sinHPos = sinH;

                            // Irradiance через горизонтальный интеграл
                            float NdotH = max(dot(viewNormal, hDir), 0.0);
                            if (NdotH > 1e-4) {
                                float atten = 1.0 - hLen / SSIL_RADIUS;
                                vec3  sCol  = SSIL_GetColor(sUV);

                                // Bilateral: нормаль соседа
                                vec3  sN    = SSIL_GetN(sUV);
                                float bw    = GI_Saturate(dot(viewNormal, sN)) * 0.5 + 0.5;

                                result.irradiance += sCol * NdotH * atten * atten * bw;
                            }
                        }
                    }
                }
            }
        }

        // ── Отрицательное направление ──
        {
            vec2  sUV  = uv - sliceDirSS * dist;
            if (clamp(sUV, vec2(0.001), vec2(0.999)) == sUV) {
                float sDepth = textureLod(depthtex0, sUV, 0.0).x;
                if (sDepth < 1.0) {
                    vec3  sVP   = SSIL_GetVP(sUV);
                    vec3  hVec  = sVP - viewPos;
                    float hLen  = length(hVec);

                    if (hLen > 1e-3 && hLen < SSIL_RADIUS) {
                        vec3  hDir = hVec / hLen;
                        float sinH = hDir.z;

                        if (sinH > sinHNeg) {
                            uint s0 = SSIL_ElevToSector(sinHNeg);
                            uint s1 = SSIL_ElevToSector(sinH);
                            maskNeg |= SSIL_FillRange(s0, s1);
                            sinHNeg = sinH;

                            float NdotH = max(dot(viewNormal, hDir), 0.0);
                            if (NdotH > 1e-4) {
                                float atten = 1.0 - hLen / SSIL_RADIUS;
                                vec3  sCol  = SSIL_GetColor(sUV);
                                vec3  sN    = SSIL_GetN(sUV);
                                float bw    = GI_Saturate(dot(viewNormal, sN)) * 0.5 + 0.5;
                                result.irradiance += sCol * NdotH * atten * atten * bw;
                            }
                        }
                    }
                }
            }
        }
    }

    result.occlusionMask = maskPos | maskNeg;
    return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// Bent Normal из bitmask-ов по всем срезам
//
//    Для каждого среза: bent = среднее направление незаблокированных секторов.
//    Суммируем по срезам → усредняем.
// ─────────────────────────────────────────────────────────────────────────────

vec3 SSIL_ComputeBentNormal(uint masks[SSIL_SLICES], float sliceAngles[SSIL_SLICES],
                             vec3 viewNormal)
{
    vec3 bent = vec3(0.0);
    float projScaleX = gbufferProjection[0][0];
    float projScaleY = gbufferProjection[1][1];

    for (int i = 0; i < SSIL_SLICES; ++i) {
        uint  mask  = masks[i];
        float angle = sliceAngles[i];
        vec3  sliceDir3D = normalize(vec3(cos(angle) / projScaleX,
                                          sin(angle) / projScaleY, 0.0));

        // Среднее незаблокированное направление в срезе
        float totalW   = 0.0;
        vec3  sliceBent = vec3(0.0);

        for (int b = 0; b < 32; ++b) {
            // Если бит не установлен → сектор открыт
            if (((mask >> uint(b)) & 1u) == 0u) {
                float theta = (float(b) / 32.0 * 2.0 - 1.0) * PI * 0.5;
                vec3 dir = cos(theta) * sliceDir3D + sin(theta) * vec3(0.0, 0.0, 1.0);
                dir = normalize(dir);
                float w = max(dot(viewNormal, dir), 0.0);
                sliceBent += dir * w;
                totalW    += w;
            }
        }

        if (totalW > 1e-5) {
            bent += sliceBent / totalW;
        }
    }

    float bl = length(bent);
    return (bl > 1e-4) ? bent / bl : viewNormal;
}

// ─────────────────────────────────────────────────────────────────────────────
// Specular Occlusion (Lagarde et al.)
// ─────────────────────────────────────────────────────────────────────────────

#if SSIL_BENT_SPECULAR == 1

float SSIL_SpecularOcclusion(vec3 N, vec3 bentNormal, float ao, float roughness) {
    float cosAngle  = dot(N, bentNormal);
    float sinAngle  = sqrt(max(0.0, 1.0 - cosAngle * cosAngle));
    float bentConeAngle = acos(GI_Saturate(cosAngle));

    // Конус доступа через AO: angleCone = acos(1 - ao)
    float aoConeAngle = acos(GI_Saturate(1.0 - ao));

    // Roughness lobe half-angle
    float roughCone = roughness * PI * 0.5;

    // Пересечение конусов
    float diff = abs(bentConeAngle - roughCone);
    float sum  = bentConeAngle + roughCone;

    float soFactor = GI_Saturate(
        (aoConeAngle - diff) / max(sum - diff, 1e-4)
    );

    return GI_Saturate(mix(ao, soFactor, GI_Saturate(roughness * 2.0)));
}

#endif // SSIL_BENT_SPECULAR

// ─────────────────────────────────────────────────────────────────────────────
// Результирующая структура
// ─────────────────────────────────────────────────────────────────────────────

struct SSIL_Result {
    vec3  irradiance;    // Indirect diffuse irradiance
    float ao;            // Ambient occlusion (0=occluded, 1=open)
    vec3  bentNormal;    // View-space bent normal
    float specOcclusion; // Specular occlusion (только при SSIL_BENT_SPECULAR)
};

// ─────────────────────────────────────────────────────────────────────────────
// МАСТЕР-ФУНКЦИЯ  CalculateSSIL_Advanced()
// ─────────────────────────────────────────────────────────────────────────────

SSIL_Result CalculateSSIL_Advanced(
    vec2 uv,
    vec3 viewPos,
    vec3 viewNormal,
    float dither,
    float roughness   // для specular occlusion
) {
    float projScaleY = gbufferProjection[1][1];
    float projScaleX = gbufferProjection[0][0];
    float viewDist   = max(-viewPos.z, 0.1);
    float rAspect    = screenPixelSize.y / screenPixelSize.x;

    // Базовый шаг в UV: radius / N ≈ pixel step
    float baseStepSS = (SSIL_RADIUS / viewDist) * projScaleY * 0.5 / float(SSIL_STEPS);
    baseStepSS = clamp(baseStepSS, screenPixelSize.y * 1.5, 0.08);

    float sliceAngleStep = PI / float(SSIL_SLICES);

    vec4  accumulated = vec4(0.0);  // xyz = irradiance, w = occlusion sum

    // Сохраняем маски и углы для bent normal
    uint  masks[SSIL_SLICES];
    float angles[SSIL_SLICES];

    for (int i = 0; i < SSIL_SLICES; ++i) {
        float angle = (float(i) + dither) * sliceAngleStep;
        angles[i]   = angle;

        // Aspect-corrected screen direction
        vec2 sliceDirSS = vec2(cos(angle) * rAspect, sin(angle));

        SSIL_SliceResult sr = SSIL_Slice(uv, viewPos, viewNormal, sliceDirSS, baseStepSS);

        accumulated.rgb += sr.irradiance;
        accumulated.a   += SSIL_BitmaskVis(sr.occlusionMask);
        masks[i]         = sr.occlusionMask;
    }

    float rS = 1.0 / float(SSIL_SLICES);

    SSIL_Result result;

    // Irradiance
    result.irradiance = accumulated.rgb * rS * PI * SSIL_STRENGTH;

    // AO: среднее визибилити → инвертируем
    float avgVis = accumulated.a * rS;
    float ao     = 1.0 - GI_Saturate(avgVis * SSIL_AO_STRENGTH);
    ao           = ao * sqrt(ao);  // гамма-кривая для визуального паритета
    result.ao    = 1.0 - ao;       // храним как "освещённость"

    // Bent Normal
    result.bentNormal = SSIL_ComputeBentNormal(masks, angles, viewNormal);

    // Specular Occlusion
    #if SSIL_BENT_SPECULAR == 1
        result.specOcclusion = SSIL_SpecularOcclusion(viewNormal, result.bentNormal,
                                                        result.ao, roughness);
    #else
        result.specOcclusion = result.ao;
    #endif

    // Применяем sky irradiance через bent normal
    #if defined IS_OVERWORLD
    {
        vec3 worldBent  = normalize(mat3(gbufferModelViewInverse) * result.bentNormal);
        float skyFactor = GI_Saturate(worldBent.y * 0.5 + 0.5);
        result.irradiance += skyIlluminance * skyFactor * result.ao * 0.15;
    }
    #endif

    return result;
}
