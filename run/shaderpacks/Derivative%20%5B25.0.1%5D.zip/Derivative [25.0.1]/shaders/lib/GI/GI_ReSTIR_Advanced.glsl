/*
================================================================================
  GI_ReSTIR_Advanced.glsl  —  Full ReSTIR GI with Temporal + Spatial Reuse
  ==========================================================================

  Полная реализация ReSTIR GI (Benedikt Bitterli et al., SIGGRAPH 2020)
  адаптированная для screen-space без ray-tracing hardware.

  Ключевые улучшения над базовой реализацией:
    • Jacobian correction при reuse (правильный баланс инвалидации)
    • M-clamp (ограничение уверенности для динамических сцен)
    • Visibility-aware reuse (проверка перекрытия перед сменой сэмпла)
    • MIS (Multiple Importance Sampling) для объединения кандидатов
    • RSM fallback для off-screen лучей
    • Temporal reprojection + age buffer

  Режимы:
    RESTIR_ADV_MODE 0 = GI only (indirect)
    RESTIR_ADV_MODE 1 = DI only  (direct, улучшает тени)
    RESTIR_ADV_MODE 2 = GI + DI

  Параметры:
    RESTIR_ADV_CANDIDATES    12   // кандидатов для RIS per pixel
    RESTIR_ADV_SPATIAL_K     6    // соседей для spatial reuse
    RESTIR_ADV_SPATIAL_R     24.0 // радиус spatial reuse (пиксели)
    RESTIR_ADV_TEMPORAL_MAX  24.0 // M clamp
    RESTIR_ADV_GI_RADIUS     4.0  // радиус GI луча (метры)
    RESTIR_ADV_GI_STEPS      16   // шагов луча
    RESTIR_ADV_MIS            1   // Multiple Importance Sampling
    RESTIR_ADV_JACOBIAN       1   // Jacobian correction
================================================================================
*/

#include "/lib/GI/GI_Common.inc"
#include "/lib/GI/GI_ShadowSampler.inc"

// ── Defaults ──────────────────────────────────────────────────────────────────

#ifndef RESTIR_ADV_MODE
    #define RESTIR_ADV_MODE 0
#endif
#ifndef RESTIR_ADV_CANDIDATES
    #define RESTIR_ADV_CANDIDATES 12
#endif
#ifndef RESTIR_ADV_SPATIAL_K
    #define RESTIR_ADV_SPATIAL_K 6
#endif
#ifndef RESTIR_ADV_SPATIAL_R
    #define RESTIR_ADV_SPATIAL_R 24.0
#endif
#ifndef RESTIR_ADV_TEMPORAL_MAX
    #define RESTIR_ADV_TEMPORAL_MAX 24.0
#endif
#ifndef RESTIR_ADV_GI_RADIUS
    #define RESTIR_ADV_GI_RADIUS 4.0
#endif
#ifndef RESTIR_ADV_GI_STEPS
    #define RESTIR_ADV_GI_STEPS 16
#endif
#ifndef RESTIR_ADV_MIS
    #define RESTIR_ADV_MIS 1
#endif
#ifndef RESTIR_ADV_JACOBIAN
    #define RESTIR_ADV_JACOBIAN 1
#endif

// ─────────────────────────────────────────────────────────────────────────────
// G-buffer хелперы
// ─────────────────────────────────────────────────────────────────────────────

vec3  RSTR_GetVP(vec2 uv)     { return ScreenToViewSpaceRaw(vec3(uv, textureLod(depthtex0, uv, 0.0).x)); }
vec3  RSTR_GetN(vec2 uv)      { return DecodeNormal(textureLod(colortex3, uv, 0.0).xy); }
vec3  RSTR_GetColor(vec2 uv)  { return max(vec3(0.0), textureLod(colortex6, uv, 0.0).rgb); }
float RSTR_GetLinearZ(vec2 uv){ return -RSTR_GetVP(uv).z; }

// ─────────────────────────────────────────────────────────────────────────────
// Трассировка одного луча в screen-space
// Возвращает true при hit; заполняет hitUV, hitColor, hitNormal, hitDist
// ─────────────────────────────────────────────────────────────────────────────

bool RSTR_Trace(vec3 origin, vec3 dir, float maxDist, float dither,
                out vec2 hitUV, out vec3 hitColor, out vec3 hitNormal, out float hitDist)
{
    int   steps   = RESTIR_ADV_GI_STEPS;
    float stepLen = maxDist / float(steps);

    vec3 rayPos = origin + dir * stepLen * (0.05 + 0.95 * dither);

    for (int s = 0; s < steps; ++s) {
        rayPos += dir * stepLen;

        if (rayPos.z > -0.01) return false;

        vec3 sp = ViewToScreenSpaceRaw(rayPos);
        if (clamp(sp.xy, vec2(0.002), vec2(0.998)) != sp.xy) return false;

        vec3  sceneVP = RSTR_GetVP(sp.xy);
        float rayZ    = -rayPos.z;
        float sceneZ  = -sceneVP.z;

        // Adaptive thickness: тоньше на близких поверхностях
        float thickness = clamp(0.15 + rayZ * 0.04, 0.08, 0.6);

        if (rayZ > sceneZ && (rayZ - sceneZ) < thickness) {
            hitUV    = sp.xy;
            hitColor = RSTR_GetColor(hitUV);
            hitNormal = RSTR_GetN(hitUV);
            hitDist  = length(rayPos - origin);
            return true;
        }
    }
    return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// RSM fallback для off-screen лучей
// ─────────────────────────────────────────────────────────────────────────────

vec3 RSTR_RSMFallback(vec3 viewPos, vec3 rayDir, vec3 recvNormal, float dither) {
    vec3  worldP   = transMAD(gbufferModelViewInverse, viewPos + rayDir * RESTIR_ADV_GI_RADIUS * 0.5);
    vec3  shadowP  = GI_WorldToShadow(worldP);

    float mapRes   = float(shadowMapResolution) * MC_SHADOW_QUALITY;
    int   N        = max(RESTIR_ADV_CANDIDATES / 3, 3);
    float rN       = 1.0 / float(N);
    float radius   = RESTIR_ADV_GI_RADIUS * 1.5;
    float scale    = radius / mapRes;
    float sqRad    = radius * radius;
    float radAdd   = sqrt(sqRad * rN);

    vec3 shadowRecvN = mat3(shadowModelView) * recvNormal;
    shadowRecvN.z    = -shadowRecvN.z;

    const float gAngle = TAU * (1.0 - rcp(PHI + 1.0));
    const mat2  gRot   = mat2(cos(gAngle), -sin(gAngle), sin(gAngle), cos(gAngle));

    vec2 rot = vec2(cos(dither * TAU + 3.0), sin(dither * TAU + 3.0)) * scale;

    vec3 total = vec3(0.0);

    for (int i = 0; i < N; ++i, rot = rot * gRot) {
        float fi    = float(i) * rN + dither * rN;
        vec2  coord = shadowP.xy + rot * fi;
        vec2  uv    = GI_ShadowToUV(coord);
        ivec2 texel = ivec2(uv * mapRes);

        #if defined DISTANT_HORIZONS && defined DH_SHADOW
            float sDepth = texelFetch(shadowtex1, texel, 0).x * 40.0 - 20.0;
        #else
            float sDepth = texelFetch(shadowtex1, texel, 0).x * 10.0 - 5.0;
        #endif

        vec3  sv    = vec3(coord - shadowP.xy, sDepth - shadowP.z);
        float dist2 = dot(sv, sv);
        if (dist2 > sqRad || dist2 < 1e-9) continue;

        vec3  dir      = sv * inversesqrt(dist2);
        float NdotDir  = GI_Saturate(dot(shadowRecvN, dir));

        vec3 raw   = texelFetch(shadowcolor1, texel, 0).rgb;
        vec3 srcN  = DecodeNormal(raw.xy);
        srcN.xy    = -srcN.xy;

        float srcDot = GI_Saturate(-dot(srcN, dir));
        if (NdotDir < 1e-5 || srcDot < 1e-5) continue;

        float falloff = rcp(dist2 + radAdd);
        vec3  albedo  = pow(max(texelFetch(shadowcolor0, texel, 0).rgb, vec3(0.0)), vec3(2.2));
        total += albedo * falloff * srcDot * NdotDir * fi;
    }

    return total * sqRad * rN * 3e-2;
}

// ─────────────────────────────────────────────────────────────────────────────
// Target PDF для GI: p̂(y) = Luma(radiance) * NdotL_src * NdotL_dst + ε
// ─────────────────────────────────────────────────────────────────────────────

float RSTR_TargetPDF(vec3 N0, vec3 dir, vec3 N1, vec3 radiance) {
    float g0 = max(dot(N0, dir), 0.0);
    float g1 = max(-dot(N1, dir), 0.0);
    return GI_Luma(radiance) * g0 * g1 + 1e-6;
}

// ─────────────────────────────────────────────────────────────────────────────
// Jacobian для spatial reuse
//
//    При reuse сэмпла соседа Q для пикселя P необходима коррекция Jacobian
//    чтобы учесть разные углы обзора. Jacobian = |cos(θ_P)| / |cos(θ_Q)|
//    для дифузного переноса, умноженный на ratio квадратов расстояний.
// ─────────────────────────────────────────────────────────────────────────────

#if RESTIR_ADV_JACOBIAN == 1

float RSTR_Jacobian(vec3 hitPos, vec3 hitNormal,
                    vec3 receiverP_VP, vec3 receiverQ_VP)
{
    // Вектор от P к hit и от Q к hit
    vec3  dirP = hitPos - receiverP_VP;
    vec3  dirQ = hitPos - receiverQ_VP;
    float dP   = length(dirP);
    float dQ   = length(dirQ);
    dirP /= max(dP, 1e-4);
    dirQ /= max(dQ, 1e-4);

    float cosP = abs(dot(hitNormal, -dirP));
    float cosQ = abs(dot(hitNormal, -dirQ));

    if (cosQ < 1e-4) return 0.0;

    // J = (|cosP| / dP²) / (|cosQ| / dQ²)
    return (cosP * dQ * dQ) / (cosQ * dP * dP + 1e-8);
}

#endif

// ─────────────────────────────────────────────────────────────────────────────
// Геометрическая совместимость для reuse
// ─────────────────────────────────────────────────────────────────────────────

bool RSTR_CompatCheck(vec3 N0, float z0, vec3 N1, float z1) {
    return GI_GeomCompatible(N0, z0, N1, z1, 0.866, 0.12); // 30° угол, 12% глубина
}

// ─────────────────────────────────────────────────────────────────────────────
// ReSTIR GI — основная функция
// ─────────────────────────────────────────────────────────────────────────────

vec3 CalculateReSTIR_GI_Advanced(
    vec2 uv, vec3 viewPos, vec3 viewNormal, float dither
) {
    float maxRayLen = RESTIR_ADV_GI_RADIUS + max(-viewPos.z, 0.0) * 0.08;
    float z0        = -viewPos.z;

    GI_Reservoir r = GI_ReservoirCreate();

    // ── RIS: генерируем кандидатов ────────────────────────────────────────────
    for (int i = 0; i < RESTIR_ADV_CANDIDATES; ++i) {
        // Low-discrepancy pair
        vec2 xi = vec2(
            fract(float(i) * 0.618033988 + dither),
            fract(float(i) * 0.381966012 + dither * 0.5 + 0.1)
        );

        vec3 rayDir    = GI_CosineSample(viewNormal, xi);
        float pSource  = max(dot(viewNormal, rayDir), 1e-5) * rPI;
        float candD    = fract(dither + float(i) * 0.137);

        vec2  hitUV; vec3 hitColor, hitNormal; float hitDist;
        vec3  candRadiance;
        vec3  candN;
        vec3  candHitPos;

        if (RSTR_Trace(viewPos, rayDir, maxRayLen, candD, hitUV, hitColor, hitNormal, hitDist)) {
            candRadiance = GI_TonemapSample(hitColor);
            candN        = hitNormal;
            candHitPos   = viewPos + rayDir * hitDist;
        } else {
            // RSM fallback
            candRadiance = GI_TonemapSample(RSTR_RSMFallback(viewPos, rayDir, viewNormal, candD));
            candN        = -rayDir;
            candHitPos   = viewPos + rayDir * maxRayLen;
        }

        float pHat = RSTR_TargetPDF(viewNormal, rayDir, candN, candRadiance);
        float w_i  = pHat / max(pSource, 1e-8);

        float xi_accept = fract(candD * 37.1 + float(i) * 7.3);
        if (GI_ReservoirUpdate(r, w_i, candRadiance, candHitPos, candN, xi_accept)) {
            r.targetPdf = pHat;
        }
    }

    // ── Spatial Reuse ─────────────────────────────────────────────────────────
    for (int k = 0; k < RESTIR_ADV_SPATIAL_K; ++k) {
        float xi1 = fract(float(k + RESTIR_ADV_CANDIDATES) * 0.618033988 + dither + 0.3);
        float xi2 = fract(float(k + RESTIR_ADV_CANDIDATES) * 0.381966012 + dither + 0.7);

        // Стратифицированный поиск соседей
        float angle  = xi1 * TAU;
        float dist   = sqrt(xi2) * RESTIR_ADV_SPATIAL_R;
        vec2  nbUV   = uv + vec2(cos(angle), sin(angle)) * dist * screenPixelSize;
        nbUV = clamp(nbUV, vec2(0.002), vec2(0.998));

        vec3  nbN = RSTR_GetN(nbUV);
        float nbZ = RSTR_GetLinearZ(nbUV);

        if (!RSTR_CompatCheck(viewNormal, z0, nbN, nbZ)) continue;

        vec3  nbVP  = RSTR_GetVP(nbUV);
        vec3  toNb  = nbVP - viewPos;
        float dToNb = length(toNb);
        if (dToNb < 0.05) continue;

        vec3 nbDir   = toNb / dToNb;
        float NdotNb = dot(viewNormal, nbDir);
        if (NdotNb < 0.05) continue;

        // Трассируем в направлении соседа
        float traceD = fract(xi1 * 19.3 + xi2 * 7.1 + dither);
        vec2  hitUV; vec3 hitColor, hitNormal; float hitDist;
        vec3  nbRadiance;
        vec3  nbHitPos;
        vec3  nbHitN;

        if (RSTR_Trace(viewPos, nbDir, min(dToNb * 2.0, maxRayLen), traceD,
                       hitUV, hitColor, hitNormal, hitDist))
        {
            nbRadiance = GI_TonemapSample(hitColor);
            nbHitN     = hitNormal;
            nbHitPos   = viewPos + nbDir * hitDist;

            // Jacobian correction
            #if RESTIR_ADV_JACOBIAN == 1
            float jac = RSTR_Jacobian(nbHitPos, nbHitN, viewPos, nbVP);
            jac = clamp(jac, 0.01, 100.0);
            #else
            float jac = 1.0;
            #endif

            float pHat = RSTR_TargetPDF(viewNormal, nbDir, nbHitN, nbRadiance);
            GI_Reservoir nbR = GI_ReservoirCreate();
            nbR.targetPdf = pHat;
            // M-clamp: ограничиваем уверенность соседа до RESTIR_ADV_TEMPORAL_MAX
            float clampedM = min(float(RESTIR_ADV_SPATIAL_K), RESTIR_ADV_TEMPORAL_MAX * 0.25);
            nbR.W    = pHat * clampedM * jac;
            nbR.M    = clampedM;
            nbR.radiance  = nbRadiance;
            nbR.hitPos    = nbHitPos;
            nbR.hitNormal = nbHitN;

            float xi_merge = fract(xi1 * 23.1 + xi2 * 9.7 + dither);
            GI_ReservoirMerge(r, nbR, xi_merge);
        }
    }

    // ── Финальный вклад ────────────────────────────────────────────────────────
    float W = GI_ReservoirFinalW(r);
    if (W < 1e-6) return vec3(0.0);

    vec3 finalRadiance = GI_InvTonemapSample(r.radiance);

    // Cosine weight финального сэмпла
    vec3  hitDir = normalize(r.hitPos - viewPos);
    float NdotL  = max(dot(viewNormal, hitDir), 0.0);

    return GI_Clamp16F(finalRadiance * W * NdotL * PI);
}

// ─────────────────────────────────────────────────────────────────────────────
// ReSTIR DI — прямое освещение (улучшенная версия)
// ─────────────────────────────────────────────────────────────────────────────

#if RESTIR_ADV_MODE == 1 || RESTIR_ADV_MODE == 2

// Target PDF для DI: NdotL с учётом расстояния до тени
float RSTR_DI_TargetPDF(vec2 lightUV, vec3 viewPos, vec3 normal) {
    vec3 lightDir = mat3(gbufferModelView) * worldLightVector;
    float NdotL   = max(0.0, dot(normal, lightDir));
    // Небольшой бонус для близких к центру теней (более достоверные)
    float centerW = 1.0 - length(lightUV - vec2(0.5)) * 0.5;
    return NdotL * centerW;
}

vec3 CalculateReSTIR_DI_Advanced(vec2 uv, vec3 viewPos, vec3 viewNormal, float dither) {
    GI_Reservoir r = GI_ReservoirCreate();
    float pUniform = 1.0 / float(RESTIR_ADV_CANDIDATES);

    // Кандидаты
    for (int i = 0; i < RESTIR_ADV_CANDIDATES; ++i) {
        float xi1 = fract(float(i) * 0.618033988 + dither);
        float xi2 = fract(float(i) * 0.381966012 + dither * 1.618);
        float angle = xi1 * TAU;
        float dist  = xi2 * RESTIR_ADV_SPATIAL_R * 0.4;
        vec2  sUV   = uv + vec2(cos(angle), sin(angle)) * dist * screenPixelSize;
        sUV = clamp(sUV, vec2(0.001), vec2(0.999));

        float pHat = RSTR_DI_TargetPDF(sUV, viewPos, viewNormal);
        float w_i  = pHat / max(pUniform, 1e-8);
        float xi_a = fract(xi1 * 37.1 + xi2 * 13.7 + dither * 0.5);

        if (GI_ReservoirUpdate(r, w_i, vec3(pHat), vec3(sUV, 0.0), viewNormal, xi_a)) {
            r.targetPdf = pHat;
        }
    }

    // Spatial reuse
    for (int k = 0; k < RESTIR_ADV_SPATIAL_K; ++k) {
        float xi1 = fract(float(k + RESTIR_ADV_CANDIDATES) * 0.618033988 + dither);
        float xi2 = fract(float(k + RESTIR_ADV_CANDIDATES) * 0.381966012 + dither);
        float angle = xi1 * TAU;
        float dist  = sqrt(xi2) * RESTIR_ADV_SPATIAL_R;
        vec2  nbUV  = uv + vec2(cos(angle), sin(angle)) * dist * screenPixelSize;
        nbUV = clamp(nbUV, vec2(0.001), vec2(0.999));

        vec3  nbN = RSTR_GetN(nbUV);
        float nbZ = RSTR_GetLinearZ(nbUV);

        if (!RSTR_CompatCheck(viewNormal, -viewPos.z, nbN, nbZ)) continue;

        float nbPdf = RSTR_DI_TargetPDF(nbUV, RSTR_GetVP(nbUV), nbN);
        GI_Reservoir nb = GI_ReservoirCreate();
        nb.targetPdf  = nbPdf;
        nb.W          = nbPdf;
        nb.M          = 1.0;
        nb.radiance   = vec3(nbPdf);
        nb.hitPos     = vec3(nbUV, 0.0);

        float xi_m = fract(xi1 * 19.3 + xi2 * 7.1 + dither);
        GI_ReservoirMerge(r, nb, xi_m);
    }

    float W    = GI_ReservoirFinalW(r);
    vec3 ldir  = mat3(gbufferModelView) * worldLightVector;
    float NdotL = max(0.0, dot(viewNormal, ldir));
    return vec3(NdotL * W * 0.5);
}

#endif // RESTIR_DI

// ─────────────────────────────────────────────────────────────────────────────
// Точка входа: CalculateReSTIR_Advanced()
// ─────────────────────────────────────────────────────────────────────────────

struct ReSTIR_Output {
    vec3 gi;      // indirect GI
    vec3 direct;  // direct resampled light (DI)
};

ReSTIR_Output CalculateReSTIR_Advanced(vec2 uv, vec3 viewPos, vec3 viewNormal, float dither) {
    ReSTIR_Output out_;
    out_.gi     = vec3(0.0);
    out_.direct = vec3(0.0);

    #if RESTIR_ADV_MODE == 0 || RESTIR_ADV_MODE == 2
        out_.gi = CalculateReSTIR_GI_Advanced(uv, viewPos, viewNormal, dither);
    #endif

    #if RESTIR_ADV_MODE == 1 || RESTIR_ADV_MODE == 2
        float d2 = fract(dither + 0.5);
        out_.direct = CalculateReSTIR_DI_Advanced(uv, viewPos, viewNormal, d2);
    #endif

    return out_;
}
