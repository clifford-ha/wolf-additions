/*
================================================================================
  GI_Master.glsl  —  Master GI Orchestrator
  ==========================================

  Объединяет все техники в единую функцию CalculateGI_Master().
  Каждую технику можно включить/выключить независимо.

  Техники:
    ┌──────────────────────────────────────────────────────────────────────┐
    │ 1. RSM Advanced (Near + Far + Multi-Bounce + SH Cache + Bent Normal)│
    │    Дефайн: GI_RSM_ENABLED                                            │
    │    Лучший для: outdoor, цветное кровотечение, пещеры                 │
    │                                                                       │
    │ 2. NBGI (Neighbour-Based GI + Light Propagation)                    │
    │    Дефайн: GI_NBGI_ENABLED                                           │
    │    Лучший для: indoor, быстрый, мало шума                            │
    │                                                                       │
    │ 3. ReSTIR GI Advanced (RIS + Spatial Reuse + Jacobian + MIS)        │
    │    Дефайн: GI_RESTIR_ENABLED                                         │
    │    Лучший для: качество, правильные bounces, самый медленный          │
    │                                                                       │
    │ 4. SSIL Bitmask (Bitmask AO + Bent Normal + Specular Occlusion)     │
    │    Дефайн: GI_SSIL_ENABLED                                           │
    │    Лучший для: AO + тонкие объекты + specular occlusion              │
    └──────────────────────────────────────────────────────────────────────┘

  Веса (GI_WEIGHT_*) и настройки в Settings.glsl или shaders.properties.

  По умолчанию включены: RSM + NBGI + SSIL (разумный баланс).
  ReSTIR выключен по умолчанию (самый дорогой), но очень хорош.

  Подключение в Deferred2.glsl:

    ...
    // В теле шейдера:
    GI_MasterResult gi = CalculateGI_Master(coord, viewPos, normal, worldNormal, dither);
    currLight.rgb = gi.indirect;
    currLight.a   = gi.ao;
================================================================================
*/

// ── Includes (порядок важен!) ─────────────────────────────────────────────────

#include "/lib/GI/GI_Common.inc"
#include "/lib/GI/GI_ShadowSampler.inc"

#ifdef GI_RSM_ENABLED
    #include "/lib/GI/GI_RSM.glsl"
#endif

#ifdef GI_NBGI_ENABLED
    #include "/lib/GI/GI_NBGI.glsl"
#endif

#ifdef GI_RESTIR_ENABLED
    #include "/lib/GI/GI_ReSTIR_Advanced.glsl"
#endif

#ifdef GI_SSIL_ENABLED
    #include "/lib/GI/GI_SSIL_Bitmask.glsl"
#endif

// ── Дефолтные веса ────────────────────────────────────────────────────────────

#ifndef GI_WEIGHT_RSM
    #define GI_WEIGHT_RSM 1.0
#endif
#ifndef GI_WEIGHT_NBGI
    #define GI_WEIGHT_NBGI 0.6
#endif
#ifndef GI_WEIGHT_RESTIR
    #define GI_WEIGHT_RESTIR 1.0
#endif
#ifndef GI_WEIGHT_SSIL
    #define GI_WEIGHT_SSIL 0.8
#endif

// AO source выбор: 0=SSIL, 1=RSM bent, 2=среднее
#ifndef GI_AO_SOURCE
    #define GI_AO_SOURCE 0
#endif

// ─────────────────────────────────────────────────────────────────────────────
// Результирующая структура
// ─────────────────────────────────────────────────────────────────────────────

struct GI_MasterResult {
    vec3  indirect;      // Итоговый непрямой свет (irradiance)
    float ao;            // Ambient occlusion (0=occluded, 1=open)
    vec3  bentNormal;    // View-space bent normal
    float specOcclusion; // Specular occlusion для отражений
};

// ─────────────────────────────────────────────────────────────────────────────
// МАСТЕР-ФУНКЦИЯ
// ─────────────────────────────────────────────────────────────────────────────

GI_MasterResult CalculateGI_Master(
    vec2 screenUV,
    vec3 viewPos,
    vec3 viewNormal,
    vec3 worldNormal,
    float dither
) {
    GI_MasterResult result;
    result.indirect      = vec3(0.0);
    result.ao            = 1.0;
    result.bentNormal    = viewNormal;
    result.specOcclusion = 1.0;

    // Разбиваем dither на независимые каналы через золотое число
    float d_rsm    = dither;
    float d_nbgi   = fract(dither + 0.2360679);   // 1/PHI²
    float d_restir = fract(dither + 0.6180339);   // 1/PHI
    float d_ssil   = fract(dither + 0.3819660);   // 1 - 1/PHI

    // ── 1. RSM Advanced ───────────────────────────────────────────────────────
    #ifdef GI_RSM_ENABLED
    {
        vec3 worldPos = transMAD(gbufferModelViewInverse, viewPos);

        RSM_Result rsmResult = CalculateRSM_Advanced(
            screenUV,
            viewPos, viewNormal,
            worldPos, worldNormal,
            d_rsm
        );

        result.indirect   += rsmResult.indirect * GI_WEIGHT_RSM;

        #if GI_AO_SOURCE == 1
            result.ao          = min(result.ao, rsmResult.ao);
            result.bentNormal  = rsmResult.bentNormal;
        #endif
    }
    #endif

    // ── 2. NBGI ───────────────────────────────────────────────────────────────
    #ifdef GI_NBGI_ENABLED
    {
        vec3 nbgiResult = CalculateNBGI(screenUV, viewPos, viewNormal, d_nbgi);
        result.indirect += nbgiResult * GI_WEIGHT_NBGI;
    }
    #endif

    // ── 3. ReSTIR GI Advanced ─────────────────────────────────────────────────
    #ifdef GI_RESTIR_ENABLED
    {
        ReSTIR_Output restirOut = CalculateReSTIR_Advanced(
            screenUV, viewPos, viewNormal, d_restir
        );

        result.indirect += restirOut.gi * GI_WEIGHT_RESTIR;

        // DI: складываем отдельно как улучшение прямого освещения
        // (возвращается в .specOcclusion как временный хак, применяется в SunLighting)
        #if RESTIR_ADV_MODE == 1 || RESTIR_ADV_MODE == 2
            result.specOcclusion = min(result.specOcclusion,
                                      1.0 - GI_Luma(restirOut.direct) * 0.5);
        #endif
    }
    #endif

    // ── 4. SSIL Bitmask ───────────────────────────────────────────────────────
    #ifdef GI_SSIL_ENABLED
    {
        // Roughness из colortex4 (packed material data)
        float roughness = texelFetch(colortex4, ivec2(gl_FragCoord.xy), 0).r;

        SSIL_Result ssilResult = CalculateSSIL_Advanced(
            screenUV, viewPos, viewNormal, d_ssil, roughness
        );

        result.indirect     += ssilResult.irradiance * GI_WEIGHT_SSIL;

        // AO из SSIL — наиболее точный источник
        #if GI_AO_SOURCE == 0
            result.ao            = min(result.ao, ssilResult.ao);
            result.bentNormal    = ssilResult.bentNormal;
            result.specOcclusion = min(result.specOcclusion, ssilResult.specOcclusion);
        #elif GI_AO_SOURCE == 2
            // Среднее
            result.ao = min(result.ao, mix(ssilResult.ao,
                                            #ifdef GI_RSM_ENABLED
                                            rsmResult.ao,
                                            #else
                                            1.0,
                                            #endif
                                            0.5));
        #endif
    }
    #endif

    // ── Финальный clamp ────────────────────────────────────────────────────────
    result.indirect      = GI_Clamp16F(result.indirect);
    result.ao            = GI_Saturate(result.ao);
    result.specOcclusion = GI_Saturate(result.specOcclusion);

    return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// Обратная совместимость с CalculateGI() из Deferred2.glsl
// Раскомментируй чтобы заменить старый API:
// ─────────────────────────────────────────────────────────────────────────────

// vec3 CalculateGI(vec2 coord, vec3 viewPos, vec3 normal, vec3 worldNormal, float dither) {
//     return CalculateGI_Master(coord, viewPos, normal, worldNormal, dither).indirect;
// }
//
// И замени в Deferred2.glsl строку:
//   currLight.rgb = CalculateRSM(viewPos, worldNormal, dither);
// на:
//   GI_MasterResult giOut = CalculateGI_Master(coord, viewPos, normal, worldNormal, dither);
//   currLight.rgb = giOut.indirect;
//   currLight.a   = giOut.ao;
