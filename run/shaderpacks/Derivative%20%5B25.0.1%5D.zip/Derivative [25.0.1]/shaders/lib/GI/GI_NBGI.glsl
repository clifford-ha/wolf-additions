/*
================================================================================
  GI_NBGI.glsl  —  Neighbour-Based GI (NBGI) + Light Propagation
  ================================================================

  NBGI — экранно-пространственный ГИ, который сэмплирует соседние пиксели
  как "виртуальные патчи", вычисляет двусторонний перенос излучения между ними,
  и опционально выполняет несколько итераций "распространения" (light propagation),
  имитируя Radiosity без вокселей.

  Техники:
    1. NBGI_Gather     — однопроходный сбор irradiance от видимых соседей
    2. NBGI_Propagate  — N итераций радиозитивного распространения в SS
    3. NBGI_Checkerboard — шахматное обновление (чётные / нечётные кадры)
    4. NBGI_EdgeAware  — геометрический весовой фильтр (bilaterally weighted)
    5. NBGI_SkyFill    — заполнение sky-irradiance для пикселей без соседей

  Настройки:
    NBGI_SLICES        6     // угловых срезов (как HBAO)
    NBGI_STEPS         6     // шагов в каждом срезе
    NBGI_RADIUS        2.0   // радиус поиска (метры, view-space)
    NBGI_PROPAGATIONS  2     // итераций распространения (0 = только gather)
    NBGI_STRENGTH      1.0   // яркость
    NBGI_BILATERAL     1     // билатеральная фильтрация по нормали и глубине
    NBGI_CHECKERBOARD  1     // шахматный апдейт (экономия ~50%)
================================================================================
*/

#include "/lib/GI/GI_Common.inc"

#ifndef NBGI_SLICES
    #define NBGI_SLICES 6
#endif
#ifndef NBGI_STEPS
    #define NBGI_STEPS 6
#endif
#ifndef NBGI_RADIUS
    #define NBGI_RADIUS 2.0
#endif
#ifndef NBGI_PROPAGATIONS
    #define NBGI_PROPAGATIONS 2
#endif
#ifndef NBGI_STRENGTH
    #define NBGI_STRENGTH 1.0
#endif
#ifndef NBGI_BILATERAL
    #define NBGI_BILATERAL 1
#endif
#ifndef NBGI_CHECKERBOARD
    #define NBGI_CHECKERBOARD 1
#endif

// ─────────────────────────────────────────────────────────────────────────────
// Вспомогательные: сэмплирование G-buffer
// ─────────────────────────────────────────────────────────────────────────────

vec3  NBGI_GetColor(vec2 uv)    { return max(vec3(0.0), textureLod(colortex6, uv, 0.0).rgb); }
vec3  NBGI_GetNormal(vec2 uv)   { return DecodeNormal(textureLod(colortex3, uv, 0.0).xy); }
float NBGI_GetDepth(vec2 uv)    { return textureLod(depthtex0, uv, 0.0).x; }
vec3  NBGI_GetViewPos(vec2 uv) {
    return ScreenToViewSpaceRaw(vec3(uv, NBGI_GetDepth(uv)));
}

// Bilateral weight — штраф за разницу нормалей и глубин
float NBGI_BilateralW(vec3 N0, float d0, vec3 N1, float d1) {
    float wN = GI_Saturate(dot(N0, N1));
    float wD = exp2(-abs(d0 - d1) / max(d0 * 0.05, 0.1) * 4.0);
    return wN * wN * wD;
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. NBGI_Gather — основной сбор irradiance в screen space
//
//    Для каждого среза находим "горизонт" (максимальный угол подъёма),
//    интегрируем цвет по области между предыдущим и текущим горизонтом.
//    Это обобщение HBAO: вместо тени / AO мы накапливаем цвет.
// ─────────────────────────────────────────────────────────────────────────────

vec3 NBGI_Gather(vec2 uv, vec3 viewPos, vec3 viewNormal, float dither) {
    float projScaleX = gbufferProjection[0][0];
    float projScaleY = gbufferProjection[1][1];
    float viewDist   = max(-viewPos.z, 0.1);

    // Шаг в экранном пространстве
    float stepSS = (NBGI_RADIUS / viewDist) * projScaleY * 0.5 / float(NBGI_STEPS);
    stepSS = clamp(stepSS, screenPixelSize.y * 1.5, 0.08);

    float rAspect  = screenPixelSize.y / screenPixelSize.x;
    float sliceStep = PI / float(NBGI_SLICES);

    vec3  totalIrr = vec3(0.0);
    float totalW   = 0.0;

    for (int i = 0; i < NBGI_SLICES; ++i) {
        float angle  = (float(i) + dither) * sliceStep;
        vec2  dirSS  = vec2(cos(angle) * rAspect, sin(angle));
        vec3  dirVS  = normalize(vec3(cos(angle) / projScaleX,
                                      sin(angle) / projScaleY,
                                      0.0));

        float sinHPos = -1.0;
        float sinHNeg = -1.0;

        // Положительное и отрицательное направление
        for (int sign = 0; sign < 2; ++sign) {
            float curSinH = -1.0;
            vec2  dirActual = (sign == 0) ? dirSS : -dirSS;

            for (int s = 1; s <= NBGI_STEPS; ++s) {
                float fi      = float(s);
                vec2  sampleUV = uv + dirActual * (stepSS * fi);

                if (clamp(sampleUV, vec2(0.001), vec2(0.999)) != sampleUV) break;

                float sDepth = NBGI_GetDepth(sampleUV);
                if (sDepth >= 1.0) break;

                vec3  sVP    = NBGI_GetViewPos(sampleUV);
                vec3  hVec   = sVP - viewPos;
                float hLen   = length(hVec);

                if (hLen < 0.02 || hLen > NBGI_RADIUS) continue;

                vec3  hDir = hVec / hLen;
                float sinH = hDir.z; // подъём в view space

                if (sinH > curSinH) {
                    float dOmega = max(0.0, sinH - curSinH);
                    float NdotH  = max(0.0, dot(viewNormal, hDir));

                    if (NdotH > 1e-4) {
                        float atten = 1.0 - hLen / NBGI_RADIUS;
                        float w     = NdotH * dOmega * atten * atten;

                        // Bilateral weight
                        #if NBGI_BILATERAL == 1
                        vec3  sN = NBGI_GetNormal(sampleUV);
                        float bw = NBGI_BilateralW(viewNormal, -viewPos.z, sN, -sVP.z);
                        w *= bw;
                        #endif

                        if (w > 1e-5) {
                            vec3 sColor = NBGI_GetColor(sampleUV);
                            totalIrr += sColor * w;
                            totalW   += w;
                        }
                    }
                    curSinH = sinH;
                }
            }
        }
    }

    if (totalW < 1e-6) return vec3(0.0);

    // Нормируем: интеграл полусферы ≈ π / NBGI_SLICES
    return GI_Clamp16F(totalIrr * (PI / float(NBGI_SLICES)) * NBGI_STRENGTH);
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. NBGI_Propagate — итеративное распространение irradiance
//
//    Симулирует radiosity в screen space:
//    каждый пиксель берёт накопленную irradiance соседей (из colortex0 prev-frame)
//    и распространяет её дальше.
//    Количество итераций = NBGI_PROPAGATIONS.
//    Для одной итерации достаточно читать из GI-буфера предыдущего кадра.
//
//    ВАЖНО: работает только с temporal accumulation (TAA / reprojection активен).
// ─────────────────────────────────────────────────────────────────────────────

#if NBGI_PROPAGATIONS > 0

vec3 NBGI_Propagate(vec2 uv, vec3 viewPos, vec3 viewNormal, float dither) {
    // Читаем предыдущий GI результат из colortex0 (хранит temporal indirect)
    // Накапливаем через соседей

    float projScaleY = gbufferProjection[1][1];
    float viewDist   = max(-viewPos.z, 0.1);

    // Маленький радиус для propagation (шаг 1-2 пикселя)
    float propRadius = NBGI_RADIUS * 0.5;
    float stepSS = (propRadius / viewDist) * projScaleY * 0.5 / float(NBGI_STEPS);
    stepSS = clamp(stepSS, screenPixelSize.y * 2.0, 0.04);

    float rAspect = screenPixelSize.y / screenPixelSize.x;

    const int   PROP_SAMPLES = max(NBGI_SLICES * 2, 8);
    float rPS    = 1.0 / float(PROP_SAMPLES);

    const float gAngle = TAU * (1.0 - rcp(PHI + 1.0));
    const mat2  gRot   = mat2(cos(gAngle), -sin(gAngle), sin(gAngle), cos(gAngle));

    vec2  rot      = vec2(cos(dither * TAU + PI), sin(dither * TAU + PI)) * stepSS;
    float ditherN  = fract(dither + 0.5) * rPS;

    vec3  totalProp = vec3(0.0);
    float totalW    = 0.0;

    for (int i = 0; i < PROP_SAMPLES; ++i, rot = rot * gRot) {
        float fi      = float(i) * rPS + ditherN;
        vec2  sampleUV = uv + rot * fi;

        if (clamp(sampleUV, vec2(0.001), vec2(0.999)) != sampleUV) continue;

        float sDepth = NBGI_GetDepth(sampleUV);
        if (sDepth >= 1.0) continue;

        vec3 sVP = NBGI_GetViewPos(sampleUV);
        vec3 sN  = NBGI_GetNormal(sampleUV);

        // Вектор от текущего пикселя к соседу
        vec3  toS  = sVP - viewPos;
        float dist = GI_SafeLen(toS);
        vec3  dir  = toS / dist;

        if (dist < 0.01 || dist > propRadius) continue;

        float NdotDir  = max(0.0, dot(viewNormal, dir));
        float SNdotDir = max(0.0, -dot(sN, dir));
        if (NdotDir < 1e-4 || SNdotDir < 1e-4) continue;

        // Читаем prev-frame GI соседа (colortex0 left half = indirect)
        vec2  prevUV   = sampleUV * 0.5;  // indirect хранится в [0..0.5] x [0..0.5]
        vec3  prevGI   = textureLod(colortex0, prevUV, 0.0).rgb;
        prevGI = GI_TonemapSample(prevGI);   // анти-firefly

        float atten = 1.0 - dist / propRadius;
        float w     = NdotDir * SNdotDir * atten * atten;

        #if NBGI_BILATERAL == 1
        float bw = NBGI_BilateralW(viewNormal, -viewPos.z, sN, -sVP.z);
        w *= bw;
        #endif

        totalProp += prevGI * w;
        totalW    += w;
    }

    if (totalW < 1e-6) return vec3(0.0);

    vec3 result = GI_InvTonemapSample(totalProp / totalW);
    return GI_Clamp16F(result * 0.3 * NBGI_STRENGTH); // propagation ослаблено
}

#endif // NBGI_PROPAGATIONS

// ─────────────────────────────────────────────────────────────────────────────
// МАСТЕР-ФУНКЦИЯ  CalculateNBGI()
// ─────────────────────────────────────────────────────────────────────────────

vec3 CalculateNBGI(vec2 uv, vec3 viewPos, vec3 viewNormal, float dither) {
    vec3 result = vec3(0.0);

    // Checkerboard: обновляем только в нужных кадрах/пикселях
    #if NBGI_CHECKERBOARD == 1
    {
        // Чётные пиксели (по сумме координат) → gather; нечётные → propagation
        int  cbBit = (int(gl_FragCoord.x) + int(gl_FragCoord.y) + frameCounter) & 1;

        if (cbBit == 0) {
            result = NBGI_Gather(uv, viewPos, viewNormal, dither);
        } else {
            #if NBGI_PROPAGATIONS > 0
                result = NBGI_Propagate(uv, viewPos, viewNormal, dither);
            #else
                result = NBGI_Gather(uv, viewPos, viewNormal, dither);
            #endif
        }
    }
    #else
    {
        // Оба pass каждый кадр
        result = NBGI_Gather(uv, viewPos, viewNormal, dither);
        #if NBGI_PROPAGATIONS > 0
            float d2 = fract(dither + 0.5);
            result += NBGI_Propagate(uv, viewPos, viewNormal, d2) * 0.5;
        #endif
    }
    #endif

    return GI_Clamp16F(result);
}
