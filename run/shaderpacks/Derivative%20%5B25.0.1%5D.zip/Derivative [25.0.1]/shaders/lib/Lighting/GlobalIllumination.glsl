const int shadowMapResolution = 2048;  // Shadowmap resolution [1024 2048 4096 8192 16384 32768]

#ifndef GI_SAMPLES
    #define GI_SAMPLES 16
#endif
#ifndef GI_STRENGTH
    #define GI_STRENGTH 1.0
#endif

#ifndef GI_STRENGTH_DEFAULT
    #define GI_STRENGTH_DEFAULT 1.0  // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#endif
#ifndef GI_STRENGTH_OPEN
    #define GI_STRENGTH_OPEN 1.2     // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.5 3.0]
#endif
#ifndef GI_STRENGTH_CAVE
    #define GI_STRENGTH_CAVE 1.0     // [0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 1.0]
#endif
#ifndef GI_RSM
    #define GI_RSM 1
#endif

// 0 = exp2  1 = smoothstep 
#ifndef GI_SHADOW_FADE_MODE
    #define GI_SHADOW_FADE_MODE 1 // [0 1]
#endif

#ifndef GI_SHADOW_FADE
    #define GI_SHADOW_FADE 2.0 // [0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0]
#endif

#ifndef GI_RADIUS_REF
    #define GI_RADIUS_REF 30.0 // [5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0]
#endif

//shadow-clip Z
#ifndef GI_DEPTH_TOLERANCE
    #define GI_DEPTH_TOLERANCE 8.5 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 4.5 5.0 5.5 6.0 6.5 7.0 7.5 8.0 8.5 9.0 9.5 10.0]
#endif

// "Wrap" (diffuse/bounce)
#ifndef GI_WRAP
    #define GI_WRAP 0.5 // [0.1..3.0, -0.1..-3.0]
#endif

#ifndef GI_COLORED_SHADOWS
    #define GI_COLORED_SHADOWS 1
#endif

#ifndef GI_GLASS_BEHIND_ALBEDO
    #define GI_GLASS_BEHIND_ALBEDO vec3(1.1)
#endif

#ifndef GI_STYLE
    #define GI_STYLE 3 // [1 2 3 4]
#endif

// 1.0 = grid 2x2 = 4 vox > 16 shamples = 64 all 4vox
#ifndef GI_RESOLUTION
    #define GI_RESOLUTION 1.0 // [0.5..2.0]
#endif

#ifndef GI_WOOL_BOUNCE_BOOST
    #define GI_WOOL_BOUNCE_BOOST 2.5
#endif

// ─── RSM_SatFix & Far-RSM Tunables ───────────────────────────────────────────
#ifndef RSM_SAT_FIX
    #define RSM_SAT_FIX 1                // [0 1]
#endif
#ifndef RSM_SAT_RADIUS
    #define RSM_SAT_RADIUS 2.5           // [1.0 1.25 1.5 2.0 2.25 2.5 3.0 3.25 3.5 4.0 4.25 4.5 5.0 5.25 5.5 6.0 7.0 8.0 9.0 10.0]
#endif
#ifndef RSM_SAT_MAX_GLASS_CONTRIB
    #define RSM_SAT_MAX_GLASS_CONTRIB 1.0 // [1.0 1.25 1.5 2.0 2.25 2.5 3.0 3.25 3.5 4.0 4.25 4.5 5.0 5.25 5.5 6.0 7.0 8.0 9.0 10.0]
#endif
#ifndef RSM_FAR_SCALE
    #define RSM_FAR_SCALE 4.0            // [1.0 1.25 1.5 2.0 2.25 2.5 3.0 3.25 3.5 4.0 4.25 4.5 5.0 5.25 5.5 6.0 7.0 8.0 9.0 10.0]
#endif
#ifndef RSM_FAR_BRIGHTNESS
    #define RSM_FAR_BRIGHTNESS 0.6       // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#endif
#ifndef RSM_DEBUG_MODE
    #define RSM_DEBUG_MODE 0             // [0 1 2 3] Режим відладки RSM
#endif

//──────────────────────────────────────────────────────────────────────────────
// Specular GI (RSM lobe)
//──────────────────────────────────────────────────────────────────────────────
#ifndef GI_SPECULAR
    #define GI_SPECULAR 1 // [0 1]
#endif
#ifndef GI_SPECULAR_STRENGTH
    #define GI_SPECULAR_STRENGTH 1.0 // [0.0..2.0]
#endif

float GI_FresnelSchlick(float cosTheta, float f0) {
    float m = saturate(1.0 - cosTheta);
    float m2 = m * m;
    return f0 + (1.0 - f0) * m2 * m2 * m;
}

float GI_DistributionGGX(float NdotH, float roughness) {
    float a2 = max(roughness * roughness, 1e-4);
    a2 *= a2;
    float d = NdotH * NdotH * (a2 - 1.0) + 1.0;
    return a2 * rcp(PI * d * d + 1e-7);
}

float GI_SpecularLobe(vec3 shadowNormal, vec3 sampleDir, vec3 viewDir, float roughness, float f0) {
    #if GI_SPECULAR == 1
        vec3 halfVec = normalize(sampleDir + viewDir);
        float NdotH  = saturate(dot(shadowNormal, halfVec));
        float NdotV  = saturate(dot(shadowNormal, viewDir));
        float NdotL  = saturate(dot(shadowNormal, sampleDir));
        if (NdotL < 1e-5 || NdotV < 1e-5) return 0.0;

        float D = GI_DistributionGGX(NdotH, roughness);
        float F = GI_FresnelSchlick(saturate(dot(halfVec, viewDir)), f0);

        return D * F * GI_SPECULAR_STRENGTH;
    #else
        return 0.0;
    #endif
}

#include "ShadowDistortion.glsl"

float GI_SkyIntensity(float skyLightmap) {
    float toCave   = smoothstep(0.10, 0.25, skyLightmap);
    float toOpen   = smoothstep(0.75, 0.92, skyLightmap);
    float strength = mix(float(GI_STRENGTH_CAVE), float(GI_STRENGTH_DEFAULT), toCave);
    strength       = mix(strength,                 float(GI_STRENGTH_OPEN),    toOpen);
    return strength;
}

bool BLS_IsSource(ivec2 texel) {
    vec3  alb      = pow(texelFetch(shadowcolor0, texel, 0).rgb, vec3(2.2));
    float skylight = texelFetch(shadowcolor1, texel, 0).z;
    float lum      = dot(alb, vec3(0.2126, 0.7152, 0.0722));
    float depthOpaque = texelFetch(shadowtex1, texel, 0).x;
    if (depthOpaque > 0.9999) return false;
    return lum > 0.32 && skylight < 0.93;
}

//──────────────────────────────────────────────────────────────────────────────
// Helpers & Accumulator
//──────────────────────────────────────────────────────────────────────────────
vec3 WorldToShadowProj(vec3 worldPos) {
    return projMAD(shadowProjection, transMAD(shadowModelView, worldPos));
}

vec2 ShadowProjToUV(vec2 proj) {
    return proj * rcp(DistortionFactor(proj)) * 0.5 + 0.5;
}

float WrapCos(float NdotL) {
    return saturate(NdotL * (1.0 - GI_WRAP) + GI_WRAP);
}

float SkylightWeight(float sampleSkylight, float receiverSkylight, float origSharpness) {
    float diff = abs(sampleSkylight - receiverSkylight);
    #if GI_SHADOW_FADE_MODE == 0
        return saturate(exp2(-sqr(diff) * origSharpness) * 2.0 - 1.5);
    #else
        return 1.0 - smoothstep(0.0, 1.0, diff * GI_SHADOW_FADE * 2.0);
    #endif
}

struct RSMSample {
    bool  valid;
    vec3  albedo;
    vec3  normal;
    float skylight;
    bool  isGlass;
    bool  isWool;
};

RSMSample GetRSMSample(ivec2 texel) {
    RSMSample s;
    s.isGlass = false;
    s.isWool  = false;

    float depthOpaque = texelFetch(shadowtex1, texel, 0).x; 
    float depthFull    = texelFetch(shadowtex0, texel, 0).x;
    vec4  rawColorFull = texelFetch(shadowcolor1, texel, 0);
    vec3  rawColor  = rawColorFull.rgb;
    vec3  srcNormal = DecodeNormal(rawColor.xy);
    srcNormal.xy    = -srcNormal.xy;

    s.isWool = rawColorFull.a > 0.5;

    vec3 rawAlbedo = pow(texelFetch(shadowcolor0, texel, 0).rgb, vec3(2.2));
    #if GI_COLORED_SHADOWS == 1
        bool isGlassTexel = depthFull < depthOpaque - 1e-5;
        if (isGlassTexel) {
            if (depthOpaque > 0.9999) {
                s.valid = false;
                return s;
            }

            s.valid    = true;
            s.albedo   = GI_GLASS_BEHIND_ALBEDO * rawAlbedo;
            s.normal   = srcNormal; 
            s.skylight = rawColor.z;
            s.isGlass  = true;
            return s;
        }
    #endif

    s.valid    = true;
    s.albedo   = rawAlbedo;
    s.normal   = srcNormal;
    s.skylight = rawColor.z;
    return s;
}

struct RSMAccum {
    vec3  total;          
    vec3  glassNear;
    float glassNearCount; 
};

RSMAccum RSMAccum_Empty() {
    RSMAccum a;
    a.total          = vec3(0.0);
    a.glassNear      = vec3(0.0);
    a.glassNearCount = 0.0;
    return a;
}

void RSMAccum_Add(inout RSMAccum acc, vec3 contrib, bool isGlass, float shadowPixelDist, float satRadiusPixels) {
    #if RSM_SAT_FIX == 1
        if (isGlass && shadowPixelDist < satRadiusPixels) {
            acc.glassNear      += contrib;
            acc.glassNearCount += 1.0;
        } else {
            acc.total += contrib;
        }
    #else
        acc.total += contrib;
    #endif
}

vec3 RSMAccum_Resolve(RSMAccum acc) {
    #if RSM_SAT_FIX == 1
        if (acc.glassNearCount > 0.0) {
            vec3 avgGlass = acc.glassNear / acc.glassNearCount;
            avgGlass = min(avgGlass, vec3(RSM_SAT_MAX_GLASS_CONTRIB));
            acc.total += avgGlass;
        }
    #else
        acc.total += acc.glassNear;
    #endif
    return acc.total;
}

float ShadowPixelDist(vec2 coord, vec2 shadowProjXY, float realRes) {
    return length((coord - shadowProjXY) * realRes);
}

//──────────────────────────────────────────────────────────────────────────────
// Near RSM Calculation (Styles 1, 2, 3, 4)
//──────────────────────────────────────────────────────────────────────────────

#if GI_STYLE == 3 || GI_STYLE == 4

// ======  ( GI_RESOLUTION SEUS Renewed Grid ) ======
vec4 CalculateRSM4(vec3 viewPos, vec3 worldNormal, float dither, float receiverRoughness, float receiverF0) {
    const int   GI_GRID    = max(int(2.0 * GI_RESOLUTION + 0.5), 1);
    const float invGrid    = 1.0 / float(GI_GRID);
    const float realRes   = float(shadowMapResolution) * MC_SHADOW_QUALITY;
    const float rSamples  = 1.0 / float(GI_SAMPLES);

    const float scale     = (GI_RADIUS * invGrid) * rcp(realRes);
    const float maxDepthDiff = (GI_RADIUS * rcp(realRes)) * GI_DEPTH_TOLERANCE;
    const float sqRadiusRef = (GI_RADIUS_REF * GI_RADIUS_REF) * (invGrid * invGrid);
    const float radiusAdd   = sqrt(sqRadiusRef * rSamples);
    const float satRadiusPixels = RSM_SAT_RADIUS;

    vec3 worldPos   = transMAD(gbufferModelViewInverse, viewPos);
    vec3 shadowProj = WorldToShadowProj(worldPos);
    vec3 shadowNormal = mat3(shadowModelView) * worldNormal;
    shadowNormal.z = -shadowNormal.z;

    vec3 shadowViewDir = normalize(mat3(shadowModelView) * (-normalize(viewPos)));
    shadowViewDir.z = -shadowViewDir.z;

    float skyLightmap = texelFetch(colortex7, ivec2(gl_FragCoord.xy * 2.0), 0).g;
    const float goldenAngle  = TAU * (1.0 - rcp(PHI1 + 1.0));
    const mat2  goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle),
                                    sin(goldenAngle),  cos(goldenAngle));
    const float cellStep = 2.0 * GI_RADIUS * rcp(realRes) * invGrid;

    RSMAccum acc = RSMAccum_Empty();
    float totalSpec = 0.0;

    for (int gy = 0; gy < GI_GRID; ++gy) {
    for (int gx = 0; gx < GI_GRID; ++gx) {

        vec2 cellCenter = (vec2(gx, gy) - float(GI_GRID - 1) * 0.5 + (dither - 0.5)) * cellStep;
        float cellHash = fract(sin(float(gx * 12.9898 + gy * 78.233 + 1.0) * 43758.5453));
        vec2 rot = sincos((dither + cellHash) * TAU) * scale;
        float cellDither = fract(dither * rSamples + cellHash);

        for (uint i = 0u; i < uint(GI_SAMPLES); ++i, rot *= goldenRotate) {
            float fi    = float(i) * rSamples + cellDither;
            vec2  coord = shadowProj.xy + cellCenter + rot * fi;
            ivec2 texel = ivec2(ShadowProjToUV(coord) * realRes);
            #if defined DISTANT_HORIZONS && defined DH_SHADOW
                float sampleDepth = texelFetch(shadowtex1, texel, 0).x * 40.0 - 20.0;
            #else
                float sampleDepth = texelFetch(shadowtex1, texel, 0).x * 10.0 - 5.0;
            #endif

            vec3 sv = vec3(coord - shadowProj.xy, sampleDepth - shadowProj.z);
            if (abs(sv.z) > maxDepthDiff) continue;

            float dist = dotSelf(sv);
            if (dist < 1e-10) continue;
            vec3  sampleDir = sv * inversesqrt(dist);

            float diffuse = WrapCos(dot(shadowNormal, sampleDir));
            if (diffuse < 1e-5) continue;
            RSMSample rsmSample = GetRSMSample(texel);
            if (!rsmSample.valid) continue;

            float bounce = WrapCos(dot(rsmSample.normal, sampleDir));
            if (bounce < 1e-5) continue;
            float falloff = rcp(dist + radiusAdd);

            #if GI_STYLE == 4
                vec2 normXY = sv.xy / scale;
                float sqNormDist = dot(normXY, normXY);
                float sharpFade = saturate(1.0 - sqNormDist * 2.0);
                sharpFade = smoothstep(0.0, 1.0, sharpFade);
                falloff *= sharpFade;
            #endif

            #if defined IS_OVERWORLD
                float skylightW = rsmSample.isGlass ? 1.0 : SkylightWeight(rsmSample.skylight, skyLightmap, 4.0);
            #else
                float skylightW = 1.0;
            #endif

            float woolBoost = rsmSample.isWool ? GI_WOOL_BOUNCE_BOOST : 1.0;
            float sampleLum = dot(rsmSample.albedo, vec3(0.2126, 0.7152, 0.0722));
            float specLobe  = GI_SpecularLobe(shadowNormal, sampleDir, shadowViewDir, receiverRoughness, receiverF0);

            vec3 contrib = rsmSample.albedo * falloff * skylightW * bounce * diffuse * fi * woolBoost;
            float pixDist = ShadowPixelDist(coord, shadowProj.xy, realRes);
            RSMAccum_Add(acc, contrib, rsmSample.isGlass, pixDist, satRadiusPixels);

            totalSpec += sampleLum * falloff * skylightW * specLobe * fi * woolBoost;
        }
    }}

    const float invGridSq = invGrid * invGrid;
    float giIntensity = GI_STRENGTH * GI_SkyIntensity(skyLightmap);
    vec3 resolved = RSMAccum_Resolve(acc);
    vec3  diffuseOut  = clamp16F(resolved * sqRadiusRef * rSamples * 5e-2 * giIntensity * invGridSq);
    float specularOut = clamp(totalSpec * sqRadiusRef * rSamples * 5e-2 * giIntensity * invGridSq, 0.0, 65535.0);
    return vec4(diffuseOut, specularOut);
}

vec3 CalculateRSM(vec3 viewPos, vec3 worldNormal, float dither) {
    return CalculateRSM4(viewPos, worldNormal, dither, 1.0, 0.0).rgb;
}

#else

// ======  ( Spiral Disk RSM with SatFix ) ======
vec4 CalculateRSM4(vec3 viewPos, vec3 worldNormal, float dither, float roughness, float f0) {
    const float realRes   = float(shadowMapResolution) * MC_SHADOW_QUALITY;
    const float rSamples  = 1.0 / float(GI_SAMPLES);
    const float scale     = GI_RADIUS * rcp(realRes);
    const float baseMaxDepthDiff = scale * GI_DEPTH_TOLERANCE;
    const float sqRadiusRef = GI_RADIUS_REF * GI_RADIUS_REF;
    const float radiusAdd   = sqrt(sqRadiusRef * rSamples);
    const float satRadiusPixels = RSM_SAT_RADIUS;

    vec3 worldPos   = transMAD(gbufferModelViewInverse, viewPos);
    vec3 shadowProj = WorldToShadowProj(worldPos);
    vec3 shadowNormal = mat3(shadowModelView) * worldNormal;
    shadowNormal.z = -shadowNormal.z;

    vec3 shadowViewDir = normalize(mat3(shadowModelView) * (-normalize(viewPos)));
    shadowViewDir.z = -shadowViewDir.z;
    float skyLightmap = texelFetch(colortex7, ivec2(gl_FragCoord.xy * 2.0), 0).g;

    const float goldenAngle  = TAU * (1.0 - rcp(PHI1 + 1.0));
    const mat2  goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle),
                                    sin(goldenAngle),  cos(goldenAngle));
    vec2 rot = sincos(dither * TAU) * scale;
    dither *= rSamples;

    RSMAccum acc = RSMAccum_Empty();
    float totalSpec = 0.0;

    for (uint i = 0u; i < uint(GI_SAMPLES); ++i, rot *= goldenRotate) {
        float fi    = float(i) * rSamples + dither;
        vec2  coord = shadowProj.xy + rot * fi;
        
        vec2 normXY = (coord - shadowProj.xy) / scale;
        float sqNormDist = dot(normXY, normXY);
        if (sqNormDist > 1.0) continue; 

        ivec2 texel = ivec2(ShadowProjToUV(coord) * realRes);
        #if defined DISTANT_HORIZONS && defined DH_SHADOW
            float sampleDepth = texelFetch(shadowtex1, texel, 0).x * 40.0 - 20.0;
        #else
            float sampleDepth = texelFetch(shadowtex1, texel, 0).x * 10.0 - 5.0;
        #endif

        vec3 sv = vec3(coord - shadowProj.xy, sampleDepth - shadowProj.z);
        float dist = dotSelf(sv);
        if (dist < 1e-10) continue;

        vec3 sampleDir = sv * inversesqrt(dist);
        float slopeBias = 1.0 - abs(dot(shadowNormal, sampleDir));
        float dynamicDepthDiff = baseMaxDepthDiff * (1.0 + slopeBias * 2.5);
        if (abs(sv.z) > dynamicDepthDiff) continue;

        float diffuse = WrapCos(dot(shadowNormal, sampleDir));
        if (diffuse < 1e-5) continue;

        RSMSample rsmSample = GetRSMSample(texel);
        if (!rsmSample.valid) continue;

        float bounce;
        #if GI_STYLE == 1
            bounce = WrapCos(dot(rsmSample.normal, sampleDir));
        #elif GI_STYLE == 2
            bounce = WrapCos(dot(rsmSample.normal, -sampleDir));
        #else
            bounce = 1.0;
        #endif

        if (bounce < 12e-5) continue;
        float falloff = 1.0 / (dist + radiusAdd * radiusAdd * 0.5);
        float edgeFade = saturate(1.0 - sqNormDist);
        falloff *= edgeFade * edgeFade; 

        #if defined IS_OVERWORLD
            float skylightW = rsmSample.isGlass ? 1.0 : SkylightWeight(rsmSample.skylight, skyLightmap, 4.0);
        #else
            float skylightW = 1.0;
        #endif

        float woolBoost = rsmSample.isWool ? GI_WOOL_BOUNCE_BOOST : 1.0;
        float sampleLum = dot(rsmSample.albedo, vec3(0.2126, 0.7152, 0.0722));
        float specLobe  = GI_SpecularLobe(shadowNormal, sampleDir, shadowViewDir, roughness, f0);

        vec3 contrib = rsmSample.albedo * falloff * skylightW * bounce * diffuse * fi * woolBoost;
        float pixDist = ShadowPixelDist(coord, shadowProj.xy, realRes);
        RSMAccum_Add(acc, contrib, rsmSample.isGlass, pixDist, satRadiusPixels);

        totalSpec += sampleLum * falloff * skylightW * specLobe * fi * woolBoost;
    }

    float giIntensity = GI_STRENGTH * GI_SkyIntensity(skyLightmap);
    vec3 resolved = RSMAccum_Resolve(acc);
    vec3  diffuseOut  = clamp16F(resolved * sqRadiusRef * rSamples * 3.5e-2 * giIntensity);
    float specularOut = clamp(totalSpec * sqRadiusRef * rSamples * 3.5e-2 * giIntensity, 0.0, 65535.0);
    return vec4(diffuseOut, specularOut);
}

vec3 CalculateRSM(vec3 viewPos, vec3 worldNormal, float dither) {
    return CalculateRSM4(viewPos, worldNormal, dither, 1.0, 0.0).rgb;
}

#endif 

//──────────────────────────────────────────────────────────────────────────────
// Far RSM GI Calculation
//──────────────────────────────────────────────────────────────────────────────
#if GI_RSM == 1
vec3 CalculateRSM_Far(vec3 viewPos, vec3 worldNormal, float dither) {
    const int   FAR_SAMPLES = max(GI_SAMPLES / 2, 4);
    const float FAR_RADIUS  = GI_RADIUS * float(RSM_FAR_SCALE);
    const float realRes     = float(shadowMapResolution) * MC_SHADOW_QUALITY;
    const float rSamples    = 1.0 / float(FAR_SAMPLES);
    const float scale       = FAR_RADIUS * rcp(realRes);
    const float maxDepthDiff = scale * GI_DEPTH_TOLERANCE;
    const float FAR_RADIUS_REF = GI_RADIUS_REF * float(RSM_FAR_SCALE);
    const float sqRadiusRef    = FAR_RADIUS_REF * FAR_RADIUS_REF;
    const float radiusAdd      = sqrt(sqRadiusRef * rSamples);
    const float satRadiusPixelsFar = RSM_SAT_RADIUS * float(RSM_FAR_SCALE);

    vec3 worldPos   = transMAD(gbufferModelViewInverse, viewPos);
    vec3 shadowProj = WorldToShadowProj(worldPos);
    vec3 shadowNorm = mat3(shadowModelView) * worldNormal;
    shadowNorm.z    = -shadowNorm.z;

    float skyLightmap = texelFetch(colortex7, ivec2(gl_FragCoord.xy * 2.0), 0).g;
    const float goldenAngle  = TAU * (1.0 - rcp(PHI1 + 1.0));
    const mat2  goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle),
                                    sin(goldenAngle),  cos(goldenAngle));
    vec2 rot = sincos(dither * TAU + PI) * scale;
    dither *= rSamples;

    RSMAccum acc = RSMAccum_Empty();

    for (int i = 0; i < FAR_SAMPLES; ++i, rot *= goldenRotate) {
        float fi    = float(i) * rSamples + dither;
        vec2  coord = shadowProj.xy + rot * fi;
        ivec2 texel = ivec2(ShadowProjToUV(coord) * realRes);
        #if defined DISTANT_HORIZONS && defined DH_SHADOW
            float sampleDepth = texelFetch(shadowtex1, texel, 0).x * 40.0 - 20.0;
        #else
            float sampleDepth = texelFetch(shadowtex1, texel, 0).x * 10.0 - 5.0;
        #endif

        vec3 sv = vec3(coord - shadowProj.xy, sampleDepth - shadowProj.z);
        if (abs(sv.z) > maxDepthDiff) continue;

        float dist2 = dotSelf(sv);
        if (dist2 < 1e-10) continue;
        vec3  sampleDir = sv * inversesqrt(dist2);

        float diffuse = WrapCos(dot(shadowNorm, sampleDir));
        if (diffuse < 1e-5) continue;

        RSMSample rsmSample = GetRSMSample(texel);
        if (!rsmSample.valid) continue;

        float bounce = WrapCos(dot(rsmSample.normal, sampleDir));
        if (bounce < 12e-5) continue;
        float falloff = rcp(dist2 + radiusAdd);

        #if defined IS_OVERWORLD
            float skylightW = SkylightWeight(rsmSample.skylight, skyLightmap, 2.0);
        #else
            float skylightW = 1.0;
        #endif

        float pixDist = ShadowPixelDist(coord, shadowProj.xy, realRes);
        vec3 contrib = rsmSample.albedo * falloff * skylightW * bounce * diffuse * fi;

        RSMAccum_Add(acc, contrib, rsmSample.isGlass, pixDist, satRadiusPixelsFar);
    }

    float giIntensity = GI_STRENGTH * GI_SkyIntensity(skyLightmap) * RSM_FAR_BRIGHTNESS;
    vec3 resolved = RSMAccum_Resolve(acc);
    return clamp16F(resolved * sqRadiusRef * rSamples * 2e-2 * giIntensity);
}
#endif

// ─── RSM Entry Points / Debug ───────────────────────────────────────────────

vec3 RSM_Calculate(vec3 viewPos, vec3 worldNormal, float dither) {
    vec3 result = CalculateRSM(viewPos, worldNormal, dither);
    #if GI_RSM == 1
        result += CalculateRSM_Far(viewPos, worldNormal, fract(dither + 0.5));
    #endif
    return result;
}

vec3 RSM_Debug(vec3 viewPos, vec3 worldNormal, float dither) {
    #if RSM_DEBUG_MODE == 1
        return CalculateRSM(viewPos, worldNormal, dither);
    #elif RSM_DEBUG_MODE == 2
        #if GI_RSM == 1
            return CalculateRSM_Far(viewPos, worldNormal, dither);
        #else
            return vec3(0.0);
        #endif
    #elif RSM_DEBUG_MODE == 3
        return RSM_Calculate(viewPos, worldNormal, dither);
    #else
        return RSM_Calculate(viewPos, worldNormal, dither);
    #endif
}