#ifndef AMBIENT_OCCLUSION_GLSL
#define AMBIENT_OCCLUSION_GLSL

#define SSAO_ENABLED // [0 1]
#define SSAO_SAMPLES 16 // [4 8 16 32]
#define SSAO_STRENGTH 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define UE4_AO_ENABLED // [0 1]
#define UE4_AO_SAMPLES 16 // [4 8 16 32 64]
#define UE4_AO_RADIUS 1.5 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define UE4_AO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define DEPTH_AO_ENABLED // [0 1]
#define DEPTH_AO_SAMPLES 8 // [4 8 16 32]
#define DEPTH_AO_RADIUS 2.0 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define DEPTH_AO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define VANILLA_AO_ENABLED // [0 1]
#define VANILLA_AO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define HBAO_ENABLED // [0 1]
#define HBAO_SAMPLES 16 // [4 8 16 32 64]
#define HBAO_RADIUS 2.0 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define HBAO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

#define GTAO_ENABLED // [0 1]
#define GTAO_SAMPLES 32 // [4 8 16 32 64]
#define GTAO_RADIUS 15.0 // [1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0 17.0 18.0 19.0 20.0]
#define GTAO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0 4.0 5.0 7.0 10.0]

//#define VXAO_ENABLED // [0 1]
#define VXAO_SAMPLES 8  // [4 8 16 32]
#define VXAO_RADIUS  1.5 // [0.5 1.0 1.5 2.0 3.0 4.0 5.0]
#define VXAO_INTENSITY 1.0 // [0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.7 2.0 2.5 3.0]


// ================================================================================================= //

#ifdef SSAO_ENABLED
float SpiralAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float rSteps = 1.0 / float(SSAO_SAMPLES);
    float maxSqLen = sqr(viewPos.z) * 0.25;
    vec2 radius = vec2(0.0);
    vec2 rayStep = vec2(0.6 / aspectRatio, 0.6) / max((far - near) * -viewPos.z / far + near, 5.0) * gbufferProjection[1][1];
    const float goldenAngle = TAU / (PHI1 + 1.0);
    const mat2 goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle), sin(goldenAngle), cos(goldenAngle));
    vec2 rot = sincos(dither * TAU) * rSteps;
    float total = 0.0;
    for (uint i = 0u; i < SSAO_SAMPLES; ++i, rot *= goldenRotate) {
        radius += rayStep;
        vec3 diff = ScreenToViewSpace(coord + rot * radius) - viewPos;
        float diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
        diff = ScreenToViewSpace(coord - rot * radius) - viewPos;
        diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
    }
    total = max0(1.0 - total * rSteps * SSAO_STRENGTH);
    return total * sqrt(total);
}

#if defined DISTANT_HORIZONS
float SpiralAO_DH(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float rSteps = 1.0 / float(SSAO_SAMPLES);
    float maxSqLen = sqr(viewPos.z) * 0.25;
    vec2 radius = vec2(0.0);
    vec2 rayStep = vec2(0.6 / aspectRatio, 0.6) / max((far - near) * -viewPos.z / far + near, 5.0) * gbufferProjection[1][1];
    const float goldenAngle = TAU / (PHI1 + 1.0);
    const mat2 goldenRotate = mat2(cos(goldenAngle), -sin(goldenAngle), sin(goldenAngle), cos(goldenAngle));
    vec2 rot = sincos(dither * TAU) * rSteps;
    float total = 0.0;
    for (uint i = 0u; i < SSAO_SAMPLES; ++i, rot *= goldenRotate) {
        radius += rayStep;
        vec3 diff = ScreenToViewSpaceDH(coord + rot * radius) - viewPos;
        float diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
        diff = ScreenToViewSpaceDH(coord - rot * radius) - viewPos;
        diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-5 && diffSqLen < maxSqLen) {
            float NdotL = saturate(dot(normal, diff * inversesqrt(diffSqLen)));
            total += NdotL * saturate(1.0 - diffSqLen / maxSqLen);
        }
    }
    total = max0(1.0 - total * rSteps * SSAO_STRENGTH);
    return total * sqrt(total);
}
#endif
#endif

#ifdef UE4_AO_ENABLED
float UE4AO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float rSteps = 1.0 / float(UE4_AO_SAMPLES);
    float maxSqLen = sqr(viewPos.z) * UE4_AO_RADIUS;
    vec2 rayStep = vec2(1.0 / aspectRatio, 1.0) * (UE4_AO_RADIUS / -viewPos.z) * gbufferProjection[1][1];
    float total = 0.0;
    vec2 rot = sincos(dither * TAU);
    const mat2 rotMat = mat2(cos(2.39996), -sin(2.39996), sin(2.39996), cos(2.39996));
    for (uint i = 0u; i < UE4_AO_SAMPLES; ++i) {
        rot *= rotMat;
        vec2 offset = rot * (float(i) + dither) * rSteps * rayStep;
        vec3 samplePos = ScreenToViewSpace(coord + offset);
        vec3 diff = samplePos - viewPos;
        float diffSqLen = dotSelf(diff);
        if (diffSqLen > 1e-4 && diffSqLen < maxSqLen) {
            float NdotL = max0(dot(normal, diff * inversesqrt(diffSqLen)) - 0.1);
            total += NdotL * max0(1.0 - diffSqLen / maxSqLen);
        }
    }
    return saturate(1.0 - (total * rSteps * UE4_AO_INTENSITY * 2.0));
}
#endif

#ifdef DEPTH_AO_ENABLED
float DepthAO(in vec2 coord, float currentDepth) {
    float ao = 0.0;
    vec2 texelSize = 1.0 / screenSize;
    float rSteps = 1.0 / float(DEPTH_AO_SAMPLES);
    for(uint i = 0u; i < DEPTH_AO_SAMPLES; i++) {
        vec2 offset = vec2(cos(float(i)), sin(float(i))) * texelSize * DEPTH_AO_RADIUS;
        float sampleDepth = texelFetch(depthtex0, ivec2((coord + offset) * screenSize), 0).x;
        float depthDiff = currentDepth - sampleDepth;
        if(depthDiff > 1e-6 && depthDiff < 0.001) {
            ao += 1.0;
        }
    }
    return saturate(1.0 - (ao * rSteps * DEPTH_AO_INTENSITY));
}
#endif

#ifdef VANILLA_AO_ENABLED
float VanillaAO(in vec3 normal, in vec3 viewPos) {
    vec3 absN = abs(normal);
    float corner = 1.0 - max(max(absN.x, absN.y), absN.z);
    return saturate(1.0 - corner * VANILLA_AO_INTENSITY);
}
#endif

#ifdef HBAO_ENABLED
float HBAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float ao = 0.0;
    float rSteps = 1.0 / float(HBAO_SAMPLES);
    vec2 stepSize = vec2(1.0 / aspectRatio, 1.0) * (HBAO_RADIUS / -viewPos.z) * gbufferProjection[1][1];

    float baseAngle = dither * TAU;
    float angleStep = TAU / float(HBAO_SAMPLES);

    for (uint i = 0u; i < HBAO_SAMPLES; i++) {
        float angle = baseAngle + float(i) * angleStep;
        vec2 dir = vec2(cos(angle), sin(angle)) * stepSize;

        vec3 samplePos = ScreenToViewSpace(coord + dir);
        vec3 diff = samplePos - viewPos;
        float distSq = dotSelf(diff);
        if (distSq < sqr(HBAO_RADIUS) && distSq > 1e-4) {
            float NdotV = dot(normal, diff) * inversesqrt(distSq);
            ao += max0(NdotV - 0.1) * max0(1.0 - distSq / sqr(HBAO_RADIUS));
        }
    }
    return saturate(1.0 - ao * rSteps * HBAO_INTENSITY);
}
#endif

#ifdef GTAO_ENABLED
float GTAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float ao = 0.0;
    float rSteps = 1.0 / float(GTAO_SAMPLES);
    vec2 stepSize = vec2(1.0 / aspectRatio, 1.0) * (GTAO_RADIUS / -viewPos.z) * gbufferProjection[1][1];

    float maxR = 0.12;
    stepSize = min(stepSize, vec2(maxR / aspectRatio, maxR));


    float angleStep = TAU / float(GTAO_SAMPLES);
    float baseAngle = dither * TAU; 

    for (uint i = 0u; i < GTAO_SAMPLES; i++) {

        float angle = baseAngle + float(i) * angleStep;
        vec2 dir = vec2(cos(angle), sin(angle));

        float stepFrac = (float(i) + dither) * rSteps;
        vec2 offset = dir * stepSize * (stepFrac + 0.1);

        vec3 samplePos = ScreenToViewSpace(coord + offset);
        vec3 diff = samplePos - viewPos;
        float distSq = dotSelf(diff);

        if (distSq < sqr(GTAO_RADIUS) && distSq > 1e-5) {
            vec3 vDir = normalize(diff);
            float NdotV = dot(normal, vDir);
         
            ao += max0(NdotV) * max0(1.0 - sqrt(distSq) / GTAO_RADIUS);
        }
    }

    return saturate(1.0 - ao * rSteps * GTAO_INTENSITY * 2.0);
}
#endif

#ifdef VXAO_ENABLED
float VXAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither) {
    float ao = 0.0;
    float rSteps = 1.0 / float(VXAO_SAMPLES);

  
    float voxelSize = VXAO_RADIUS / float(VXAO_SAMPLES);


    vec3 up = abs(normal.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 tangent   = normalize(cross(up, normal));
    vec3 bitangent = cross(normal, tangent);


    const float goldenAngle = TAU / (PHI1 + 1.0);
    float fi = dither * TAU;

    for (uint i = 0u; i < VXAO_SAMPLES; ++i, fi += goldenAngle) {

        float t = (float(i) + dither) * rSteps;
        float cosTheta = 1.0 - t;        
        float sinTheta = sqrt(1.0 - cosTheta * cosTheta);


        vec3 sampleDir = tangent   * (sinTheta * cos(fi))
                       + bitangent * (sinTheta * sin(fi))
                       + normal    * cosTheta;


        float stepDist = voxelSize * (float(i) + 0.5 + dither);
        vec3 sampleViewPos = viewPos + sampleDir * stepDist;

        vec4 sampleClip = gbufferProjection * vec4(sampleViewPos, 1.0);
        vec2 sampleUV   = (sampleClip.xy / sampleClip.w) * 0.5 + 0.5;


        vec3 realViewPos = ScreenToViewSpace(sampleUV);

        float expectedZ = sampleViewPos.z;
        float realZ     = realViewPos.z;

        float depthDiff = expectedZ - realZ; 
        if (depthDiff > 0.05 && depthDiff < VXAO_RADIUS) {
   
            float weight = max0(1.0 - depthDiff / VXAO_RADIUS);

            float NdotS  = saturate(dot(normal, sampleDir));
            ao += NdotS * weight;
        }
    }

    return saturate(1.0 - ao * rSteps * VXAO_INTENSITY * 2.0);
}
#endif

float CalculateCombinedAO(in vec2 coord, in vec3 viewPos, in vec3 normal, float dither, float depth) {
    float finalAO = 1.0;
    
    #ifdef SSAO_ENABLED
        #if defined DISTANT_HORIZONS
        if (depth >= 1.0) finalAO *= SpiralAO_DH(coord, viewPos, normal, dither);
        else
        #endif
        finalAO *= SpiralAO(coord, viewPos, normal, dither);
    #endif

    #ifdef UE4_AO_ENABLED
        finalAO *= UE4AO(coord, viewPos, normal, dither);
    #endif

    #ifdef DEPTH_AO_ENABLED
        finalAO *= DepthAO(coord, depth);
    #endif

    #ifdef VANILLA_AO_ENABLED
        finalAO *= VanillaAO(normal, viewPos);
    #endif

    #ifdef HBAO_ENABLED
        finalAO *= HBAO(coord, viewPos, normal, dither);
    #endif

    #ifdef GTAO_ENABLED
        finalAO *= GTAO(coord, viewPos, normal, dither);
    #endif

	    #ifdef VXAO_ENABLED
        finalAO *= VXAO(coord, viewPos, normal, dither);
    #endif

    return finalAO;
}

#endif