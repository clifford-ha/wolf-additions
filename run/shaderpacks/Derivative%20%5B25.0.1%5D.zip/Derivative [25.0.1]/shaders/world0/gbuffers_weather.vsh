#version 450 compatibility

#include "/program/Gbuffers/WeatherDef.glsl"

out float tint;
out vec2  texcoord;
out float dropHeight;    // 0 = у земли, 1 = высоко
out vec2  fallDirScreen; // направление падения в screen-space
out float dropRandom;    // уникальное случайное значение на каждую каплю [0..1]
out float nearFade;      // fade вблизи камеры

uniform float frameTimeCounter;
uniform vec3  cameraPosition;
uniform mat4  gbufferModelView;
uniform mat4  gbufferModelViewInverse;
uniform mat4  gbufferProjection;
uniform vec2  taaOffset;

// Быстрый хэш для уникальности каждой капли
float hash(vec3 p) {
    p = fract(p * vec3(127.1, 311.7, 74.7));
    p += dot(p, p.yzx + 19.19);
    return fract((p.x + p.y) * p.z);
}

void main() {
    texcoord = mat2(gl_TextureMatrix[0]) * gl_MultiTexCoord0.xy + gl_TextureMatrix[0][3].xy;
    texcoord /= RAIN_SIZE;

    vec4 worldPos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    float distFromCam = length(worldPos.xyz);

    // ── Дальний fade ────────────────────────────────────────────────────────
    float farFade = 1.0;
    if (float(RAIN_DIST) > 0.001) {
        farFade = smoothstep(float(RAIN_DIST) * 0.8, float(RAIN_DIST), distFromCam);
    }

    // ── Ближний fade (новая настройка RAIN_NEAR_FADE_DIST) ──────────────────
    // Капли слишком близко к камере — выглядят странно, плавно убираем их
    nearFade = smoothstep(0.0, float(RAIN_NEAR_FADE_DIST), distFromCam);

    tint = gl_Color.a * RAIN_VISIBILITY * farFade;

    // ── Высота капли ────────────────────────────────────────────────────────
    float absoluteY = worldPos.y + cameraPosition.y;
    dropHeight = clamp(1.0 - (cameraPosition.y - absoluteY) * 0.04, 0.0, 1.0);

    // ── Случайное значение на каплю (по world-позиции) ──────────────────────
    // Используем позицию капли в world-space как seed — одна капля = один хэш
    dropRandom = hash(floor(worldPos.xyz * 3.0 + cameraPosition));

    // ── Ветер + турбулентность ───────────────────────────────────────────────
    float windPos = dot(worldPos.xyz + cameraPosition, vec3(2.0));

    // Основной ветер (RAIN_SPEED — новая настройка, было захардкожено 0.1)
    float wind = fma(sin(windPos + frameTimeCounter * RAIN_SPEED), 0.25, 0.25);

    // Вторичная турбулентность: каждая капля качается немного по-своему
    // RAIN_TURBULENCE — новая настройка амплитуды
    float turbOffset = dropRandom * 6.2831; // уникальная фаза
    float turbFreq   = 0.7 + dropRandom * 0.6;
    float turbulence = sin(frameTimeCounter * turbFreq * RAIN_SPEED + turbOffset) * RAIN_TURBULENCE;

    vec2 windDir = vec2(RAIN_WIND_X, RAIN_WIND_Y);
    worldPos.xz -= worldPos.y * (wind + turbulence) * windDir * RAIN_DISTURBANCE_INTESIVITY;

    // ── Растяжение вдоль вектора падения (motion streak) ────────────────────
    vec3 fallDirWorld = normalize(vec3(RAIN_WIND_X * wind, -1.0, RAIN_WIND_Y * wind));
    vec3 fallDirView  = mat3(gbufferModelView) * fallDirWorld;

    float vertexAxisT = (gl_MultiTexCoord0.y - 0.5) * 2.0;

    vec3 viewPos = (gbufferModelView * worldPos).xyz;
    viewPos += fallDirView * RAIN_STREAK_LENGTH * vertexAxisT;

    // Направление падения в screen-space
    vec4 p0 = gbufferProjection * vec4(viewPos, 1.0);
    vec4 p1 = gbufferProjection * vec4(viewPos + fallDirView * 0.01, 1.0);
    fallDirScreen = normalize((p1.xy / p1.w) - (p0.xy / p0.w));

    gl_Position = gbufferProjection * vec4(viewPos, 1.0);

    #ifdef TAA_ENABLED
        gl_Position.xy += taaOffset * gl_Position.w * 0.5;
    #endif
}
