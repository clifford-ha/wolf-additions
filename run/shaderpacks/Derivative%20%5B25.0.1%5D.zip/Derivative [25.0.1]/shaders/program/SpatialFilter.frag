out vec4 indirectData;

/* DRAWBUFFERS:0 */

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"
#include "/lib/Head/Functions.inc"

void main() {
    ivec2 texel = ivec2(gl_FragCoord.xy);

    // Читаем исходный пиксель освещения
    indirectData = texelFetch(colortex0, texel, 0);

    // Обработка только в пределах половинного разрешения буфера
    if (all(lessThan(texel, ceil(screenSize * 0.5)))) {
        float depth = texelFetch(depthtex0, texel * 2, 0).x;

        if (depth < 1.0) {
            ivec2 shift = ivec2(viewWidth * 0.5, 0);
            vec4 normalDepthData = texelFetch(colortex0, texel + shift, 0);
            vec3 viewPos = ScreenToViewSpace(vec3(gl_FragCoord.xy * screenPixelSize * 2.0, depth));
            float NdotV = saturate(dot(normalDepthData.xyz, -normalize(viewPos)));

            float sumWeight = 1.0;

            // Сборка сэмплов в окрестности 3x3
            for (uint i = 0u; i < 8u; ++i) {
                ivec2 offset = offset3x3N[i];
                ivec2 sampleTexel = texel + offset;

                // Проверка выхода за границы рабочей области
                if (clamp(sampleTexel, ivec2(0), ivec2(screenSize * 0.5) - 1) != sampleTexel) continue;

                vec4 prevData = texelFetch(colortex0, sampleTexel + shift, 0);

                // Вычисление весов: расстояние, глубина (дистанция) и нормали
                float weight = exp2(-dotSelf(offset) * 0.05);
                weight *= exp2(-abs(prevData.w - normalDepthData.w) * 4.0 * NdotV); // Вес глубины
                weight *= pow16(max0(dot(prevData.xyz, normalDepthData.xyz)));     // Вес нормали

                vec4 sampleLight = texelFetch(colortex0, sampleTexel, 0);

                indirectData += sampleLight * weight;
                sumWeight += weight;
            }

            indirectData /= sumWeight;
        }
    }
}