in vec2 screenCoord;

#include "/lib/Head/Common.inc"
#include "/lib/Head/Uniforms.inc"



#ifndef GI_SPEC_COLORTEX
    #define GI_SPEC_COLORTEX colortex30
#endif

uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2D shadowcolor1;

uniform bool worldTimeChanged;
#ifdef RESTIR_ENABLED
	uniform sampler2D colortex8;
#endif


#ifdef GI_ENABLED
	#ifndef GI_SPECULAR
		#define GI_SPECULAR 1
	#endif
#endif

#if defined GI_ENABLED && GI_SPECULAR == 1
	uniform sampler2D GI_SPEC_COLORTEX;
#endif

layout(location = 0) out vec4 indirectData;

#if defined IS_OVERWORLD
	layout(location = 1) out vec4 skyboxData;
	#if defined GI_ENABLED && GI_SPECULAR == 1
		layout(location = 2) out vec4 specularGIData;
		/* RENDERTARGETS: 0,1,30 */
	#else
		/* DRAWBUFFERS:01 */
	#endif

	#if TEMPORAL_UPSCALING == 2
		const ivec2[4] checkerboardOffset = ivec2[4](
			ivec2(0, 0), ivec2(1, 1),
			ivec2(1, 0), ivec2(0, 1)
		);
	#elif TEMPORAL_UPSCALING == 3
		const ivec2[9] checkerboardOffset = ivec2[9](
			ivec2(0, 0), ivec2(2, 0), ivec2(0, 2),
			ivec2(2, 2), ivec2(1, 1), ivec2(1, 0),
			ivec2(1, 2), ivec2(0, 1), ivec2(2, 1)
		);
	#elif TEMPORAL_UPSCALING == 4
		const ivec2[16] checkerboardOffset = ivec2[16](
			ivec2(0, 0), ivec2(2, 0), ivec2(0, 2), ivec2(2, 2),
			ivec2(1, 1), ivec2(3, 1), ivec2(1, 3), ivec2(3, 3),
			ivec2(1, 0), ivec2(3, 0), ivec2(1, 2), ivec2(3, 2),
			ivec2(0, 1), ivec2(2, 1), ivec2(0, 3), ivec2(2, 3)
		);
	#endif

	vec4 textureCatmullRom(in sampler2D tex, in vec2 coord) {
		vec2 res = textureSize(tex, 0);
		vec2 screenPixelSize = 1.0 / res;
		vec2 position = coord * res;
		vec2 centerPosition = floor(position - 0.5) + 0.5;

		vec2 f = position - centerPosition;
		vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
		vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
		vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
		vec2 w3 = f * f * (-0.5 + 0.5 * f);

		vec2 w12 = w1 + w2;
		vec2 tc0  = screenPixelSize * (centerPosition - 1.0);
		vec2 tc3  = screenPixelSize * (centerPosition + 2.0);
		vec2 tc12 = screenPixelSize * (centerPosition + w2 * rcp(w12));

		vec4 color = vec4(0.0);
		color += textureLod(tex, vec2(tc0.x,  tc0.y),  0) * w0.x  * w0.y;
		color += textureLod(tex, vec2(tc12.x, tc0.y),  0) * w12.x * w0.y;
		color += textureLod(tex, vec2(tc3.x,  tc0.y),  0) * w3.x  * w0.y;
		color += textureLod(tex, vec2(tc0.x,  tc12.y), 0) * w0.x  * w12.y;
		color += textureLod(tex, vec2(tc12.x, tc12.y), 0) * w12.x * w12.y;
		color += textureLod(tex, vec2(tc3.x,  tc12.y), 0) * w3.x  * w12.y;
		color += textureLod(tex, vec2(tc0.x,  tc3.y),  0) * w0.x  * w3.y;
		color += textureLod(tex, vec2(tc12.x, tc3.y),  0) * w12.x * w3.y;
		color += textureLod(tex, vec2(tc3.x,  tc3.y),  0) * w3.x  * w3.y;

		return color;
	}
#else
	#if defined GI_ENABLED && GI_SPECULAR == 1
		layout(location = 1) out vec4 specularGIData;
		/* RENDERTARGETS: 0,30 */
	#else
		/* DRAWBUFFERS:05 */
	#endif
#endif

#include "/lib/Head/Functions.inc"
#include "/lib/Head/Material.inc"

#if defined SSAO_ENABLED || defined UE4_AO_ENABLED || defined DEPTH_AO_ENABLED || defined VANILLA_AO_ENABLED || defined HBAO_ENABLED || defined GTAO_ENABLED
	#include "/lib/Lighting/AmbientOcclusion.glsl"
#endif
#ifdef GI_ENABLED
	#include "/lib/Lighting/GlobalIllumination.glsl"
	#include "/lib/GI/GI_RSM.glsl"
#endif

#ifdef SSGI_ENABLED
	#include "/lib/Lighting/SSGI.glsl"
#endif

vec4 TemporalLightAccumulation(out float specularGI) {
	specularGI = 0.0;

	if (all(lessThan(screenCoord, vec2(0.5)))) {
		ivec2 texel = ivec2(gl_FragCoord.xy) * 2;
		float depth = GetDepth(texel);

		#if defined DISTANT_HORIZONS
			float dhDepth = GetDepthDH(texel);
			if (min(dhDepth, depth) >= 1.0) return vec4(0.0);
		#else
			if (depth >= 1.0) return vec4(0.0);
		#endif

		vec2 coord     = screenCoord * 2.0;
		vec3 screenPos = vec3(coord, depth);
		vec3 viewPos   = ScreenToViewSpace(screenPos);
		#if defined DISTANT_HORIZONS
			if (depth >= 1.0) {
				screenPos = vec3(coord, dhDepth);
				viewPos   = ScreenToViewSpaceDH(screenPos);
			}
		#endif

		vec3 normal      = GetNormals(texel);
		vec3 worldNormal = mat3(gbufferModelViewInverse) * normal;

		vec4 currLight = vec4(vec3(0.0), 1.0);

		#if defined SSAO_ENABLED || defined UE4_AO_ENABLED || defined DEPTH_AO_ENABLED || defined VANILLA_AO_ENABLED || defined HBAO_ENABLED || defined GTAO_ENABLED
			float dither = texelFetch(noisetex, texel & 255, 0).a;
			dither = fract(dither + frameCounter * rPI);
			
			if (depth > 0.56 || depth >= 1.0) {
				currLight.a *= CalculateCombinedAO(coord, viewPos, normal, dither, depth);
			}
		#endif

		#ifdef GI_ENABLED
			float giDither = RandNextF();
			#if RSM_DEBUG_MODE != 0
				currLight.rgb = RSM_Debug(viewPos, worldNormal, giDither);
				return currLight;
			#else
				#if GI_SPECULAR == 1
					Material receiverMat = GetMaterialData(texelFetch(colortex0, texel, 0).xy);
					vec4 rsmResult = RSM_Calculate4(viewPos, worldNormal, giDither, receiverMat.roughness, receiverMat.f0);
					currLight.rgb  = rsmResult.rgb;
					specularGI     = rsmResult.a;
				#else
					vec3 rsmLight = RSM_Calculate(viewPos, worldNormal, giDither);
					currLight.rgb = rsmLight;
				#endif
			#endif
		#endif

		#ifdef SSGI_ENABLED
			vec3  ssgiViewNormal = mat3(gbufferModelView) * worldNormal;
			float ssgiNoise  = texelFetch(noisetex, texel & 255, 0).a;
			float ssgiDither = fract(ssgiNoise + frameCounter * 0.618034);
			vec3  ssgiLight  = CalculateSSGI(viewPos, ssgiViewNormal, ssgiDither);
			currLight.rgb   += ssgiLight;
		#endif

		#ifdef RESTIR_ENABLED
			vec4 restirA     = texelFetch(colortex8, texel / 2, 0);
			vec3 restirLight = restirA.rgb * max(restirA.a, 0.0);

			#ifdef GI_ENABLED
				currLight.rgb += restirLight * 0.7;
			#else
				currLight.rgb += restirLight;
			#endif
		#endif

		vec2 prevCoord = Reproject(screenPos).xy;

		#if defined DISTANT_HORIZONS
			if (depth >= 1.0) prevCoord = ReprojectDH(screenPos).xy;
		#endif

		if (clamp(prevCoord, screenPixelSize, 1.0 - screenPixelSize) != prevCoord || worldTimeChanged) return currLight;

		prevCoord *= 0.5;
		vec4 prevData = texture(colortex0, prevCoord + vec2(0.5, 0.0));

		float currDist       = GetDepthLinear(depth);
		float cameraMovement = distance(cameraPosition, previousCameraPosition);

		float weight = step((distance(currDist, prevData.a) - cameraMovement) / abs(currDist), 0.1);
		weight *= step(0.5, dot(normal, prevData.xyz));
		vec4 blendWeight = vec4(vec3(0.97), 0.75) * weight;
		vec4 prevLight   = texture(colortex0, prevCoord);

		#if defined GI_ENABLED && GI_SPECULAR == 1
			float prevSpecular = texture(GI_SPEC_COLORTEX, prevCoord).r;
			specularGI = clamp(mix(specularGI, prevSpecular, 0.9 * weight), 0.0, 65535.0);
		#endif

		return clamp16F(mix(currLight, prevLight, blendWeight));
	} else if (screenCoord.y < 0.5) {
		ivec2 texel = ivec2(gl_FragCoord.xy) * 2 - ivec2(viewWidth, 0);
		float depth = GetDepth(texel);
		#if defined DISTANT_HORIZONS
			float dhDepth = GetDepthDH(texel);
			if (min(dhDepth, depth) >= 1.0) return vec4(0.0);
			float dist = depth < 1.0 ? GetDepthLinear(depth) : GetDepthLinearDH(dhDepth);
		#else
			if (depth >= 1.0) return vec4(0.0);
			float dist = GetDepthLinear(depth);
		#endif

		vec3 normal = GetNormals(texel);
		return vec4(normal, dist);
	}
}

void main() {
	float specularGI = 0.0;

	#if defined GI_ENABLED || defined SSAO_ENABLED || defined UE4_AO_ENABLED || defined DEPTH_AO_ENABLED || defined VANILLA_AO_ENABLED || defined HBAO_ENABLED || defined GTAO_ENABLED || defined SSGI_ENABLED || defined RESTIR_ENABLED
		indirectData = TemporalLightAccumulation(specularGI);
	#else
		indirectData = vec4(vec3(0.0), 1.0);
	#endif

	#if defined GI_ENABLED && GI_SPECULAR == 1
		specularGIData = vec4(specularGI, 0.0, 0.0, 1.0);
	#endif

	#if defined IS_OVERWORLD
		#if defined DISTANT_HORIZONS
			#define Reproject ReprojectDH
		#endif

		ivec2 texel = ivec2(gl_FragCoord.xy);

		vec2 previousCoord = Reproject(vec3(screenCoord, 1.0)).xy;
		vec2 historyData   = texture(colortex0, previousCoord * 0.5 + 0.5).xy;
		if (all(greaterThanEqual(screenCoord, vec2(0.5)))) {
			indirectData.x = 1.0 + texture(colortex0, Reproject(vec3(screenCoord * 2.0 - 1.0, 1.0)).xy * 0.5 + 0.5).x;
			ivec2 texel    = ivec2(gl_FragCoord.xy) * 2 - ivec2(screenSize);
			indirectData.y = 1.0 - GetDepth(texel);
		}

		if (saturate(previousCoord) != previousCoord
		 || GetDepth(texel) >= 1.0 && historyData.y > 1e-6
		 || worldTimeChanged) {
			skyboxData = textureBicubic(colortex2, min(screenCoord * rcp(float(TEMPORAL_UPSCALING)), rcp(TEMPORAL_UPSCALING) - screenPixelSize));
		} else {
			const int cloudsRenderFactor = TEMPORAL_UPSCALING * TEMPORAL_UPSCALING;

			ivec2 offset       = checkerboardOffset[frameCounter % cloudsRenderFactor];
			ivec2 currentTexel = clamp((texel - offset) / TEMPORAL_UPSCALING, ivec2(0), ivec2(screenSize) / TEMPORAL_UPSCALING - 1);
			float cameraMovement = expf(-16.0 * distance(cameraPosition, previousCameraPosition));
			historyData.x = min(historyData.x, MAX_BLENDED_FRAMES);
			float blendWeight = 1.0 - rcp(max(historyData.x - cloudsRenderFactor, 1.0));
			blendWeight *= mix(1.0, cameraMovement, blendWeight);
			vec2 pixelVelocity = 1.0 - abs(fract(previousCoord * screenSize) * 2.0 - 1.0);
			blendWeight *= sqrt(pixelVelocity.x * pixelVelocity.y) * 0.75 + 0.25;
			blendWeight *= mix(1.0, sqrt(pixelVelocity.x * pixelVelocity.y), blendWeight);
			vec4 prevData = clamp16F(textureCatmullRom(colortex1, previousCoord));
			skyboxData = texelFetch(colortex2, currentTexel, 0);
			if (offset == texel % TEMPORAL_UPSCALING) {
				skyboxData = mix(skyboxData, prevData, blendWeight);
			} else skyboxData = prevData;
		}
	#endif
}